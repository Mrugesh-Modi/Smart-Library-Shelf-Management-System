document.title="Book Configuration";
$(document).ready(function ()
{

    var counter = 0;
    $("#title").change(function ()
    {

        $("#booktitle").find("span").remove();
        if (/^[A-Za-z0-9 ]+$/i.test(this.value))
        {
            counter = 1;
            var title = $(this).val();
            var fetchBookInfo = "fetchBookInfo";
            $.ajax(
                    {
                        url: 'http://localhost:8080/SmartLibraryShelfManagement/LibrarianCRUDOperation',
                        type: 'POST',
                        data: {value: title, fetchBookInfo: fetchBookInfo},
                        success: function (data1)
                        {
                            var data = data1.toString();
                            var rs = data.split(",");
                            if (rs.length > 1)
                            {
                                alert(rs.length);
                                alert("Book title already avaliable you can only add the quntity");
                                $(".item_unit").hide();
                                $(".second").append('<input type="text" class="form-control readonly" id="txt_subsection_id" name="txt_subsection_id" required >');
                                $("#txt_subsection_id").val(rs[0].toString());
                                $("#txt_bookauthor").val(rs[1].toString());
                                $("#txt_bookpublication").val(rs[2].toString());
                                var d1 = rs[3].toString();
                                var isbn = d1.split("-");
                                $("#txt_eanprefix").val(isbn[0].toString());
                                $("#txt_Registration").val(isbn[1].toString());
                                $("#txt_Registrant").val(isbn[2].toString());
                                $("#txt_Publication").val(isbn[3].toString());
                                $("#txt_CheckDigit").val(isbn[4].toString());
                                $("#txt_booklanguage").val(rs[4].toString());
                                $("#txt_bookpaperback").val(rs[5].toString());
                                var d = rs[6].toString();
                                var dimension = d.split("*");
                                $("#txt_bookhight").val(dimension[0].toString());
                                $("#txt_bookwidth").val(dimension[1].toString());
                                $("#txt_booklength").val(dimension[2].toString());
                                $(".readonly").attr("readonly", "readonly");
                                $("#txt_bookquantity").focus();
                                $("#changelabel").text("Book Category");
                            } else
                            {
                                $(".readonly").val("");
                                $(".readonly").removeAttr("readonly");
                                $(".item_unit").show();
                                $("#changelabel").text("Select Category of book");
                                $("#txt_subsectionid").remove();


                            }
                        }

                    });
        } else
        {
            counter = 0;
            $("#booktitle").append("<span style='color:red;'>Title must be Alphabetes only.</span>");
        }

    });

    $("#txt_bookauthor").change(function ()
    {

        $("#bookauthor").find("span").remove();
        if (!/^[A-Za-z .]+$/i.test(this.value))
        {
            counter = 1;
            $("#bookauthor").append("<span style='color:red;'>Author Name must be Alphabetes only.</span>");
        } else
        {
            counter = 0;
        }
    });

    $("#txt_eanprefix").change(function ()
    {

        $("#bookisbn").find("span").remove();
        if (!/^[0-9]{3}$/i.test(this.value))
        {
            counter = 1;
            $("#bookisbn").append("<span style='color:red;'>EAN Prefix Must be digit and length is 3.</span>");
        } else
        {
            counter = 0;
        }
    });

    $("#txt_Registration").change(function ()
    {
        $("#bookisbn").find("span").remove();
        if (!/^[0-9]{2}$/i.test(this.value))
        {
            counter = 1;
            $("#bookisbn").append("<span style='color:red;'>Registration group Must be digit and length is 2.</span>");
        } else
        {
            counter = 0;
        }
    });

    $("#txt_Registrant").change(function ()
    {
        $("#bookisbn").find("span").remove();
        if (!/^[0-9]{5}$/i.test(this.value))
        {
            counter = 1;
            $("#bookisbn").append("<span style='color:red;'>Registrant Must be digit and length is 5.</span>");
        } else
        {
            counter = 0;
        }
    });

    $("#txt_Publication").change(function ()
    {
        $("#bookisbn").find("span").remove();
        if (!/^[0-9]{2}$/i.test(this.value))
        {
            counter = 1;
            $("#bookisbn").append("<span style='color:red;'>Publication Must be digit and length is 2.</span>");
        } else
        {
            counter = 0;
        }
    });

    $("#txt_CheckDigit").change(function ()
    {
        $("#bookisbn").find("span").remove();
        if (!/^[0-9]{1}$/i.test(this.value))
        {
            counter = 1;
            $("#bookisbn").append("<span style='color:red;'>CheckDigit Must be digit and length is 1.</span>");
        } else
        {
            counter = 0;
        }
    });


    $("#txt_booklanguage").change(function ()
    {
        $("#booklang").find("span").remove();
        if (!/^[A-Za-z]+$/i.test(this.value))
        {
            counter = 1;
            $("#booklang").append("<span style='color:red;'>Book language must be Alphabetes</span><br/>");
        } else
        {
            counter = 0;
        }
    });

    $("#txt_bookpaperback").change(function ()
    {
        $("#bookpaperback").find("span").remove();
        if (!/^[0-9]{1,5}$/i.test(this.value))
        {
            counter = 1;
            $("#bookpaperback").append("<span style='color:red;'>Book PaperBack must be Digits</span>");
        } else
        {
            counter = 0;
        }
    });


    $("#btn_submit").click(function (event)
    {
        if (counter == 0)
        {
            $(this).attr("formaction", "http://localhost:8080/SmartLibraryShelfManagement/LibrarianCRUDOperation");
        } else
        {
            event.preventDefault();
        }

    });



});