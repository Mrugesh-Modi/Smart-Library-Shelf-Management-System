// Your web app's Firebase configuration
var firebaseConfig = {
    apiKey: "AIzaSyAs1jR5QXPpPTSGwrQG6jb6j2ZqTJg56Wo",
    authDomain: "mytesting-d13a7.firebaseapp.com",
    databaseURL: "https://mytesting-d13a7.firebaseio.com",
    projectId: "mytesting-d13a7",
    storageBucket: "mytesting-d13a7.appspot.com",
    messagingSenderId: "923858135834",
    appId: "1:923858135834:web:d1213b256c645abd389aa3",
    measurementId: "G-8JE053NJ1K"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
firebase.analytics();
var arrReaderId = [];
var arrData = [];
firebase.database().ref().on('value', function (snapshot_outer)
{
    var Key = "";

    snapshot_outer.forEach(function (childSnapshot_outer)
    {
        var Data = "";
        var DataSet = new Set();
        Key = childSnapshot_outer.key;
        arrReaderId.push(Key);

        firebase.database().ref(Key).on('value', function (snapshot_inner)
        {

            snapshot_inner.forEach(function (childSnapshot_inner)
            {
                var strdata = childSnapshot_inner.val().toString();
                var dump = strdata.toString();
                DataSet.add(dump.substr(0, 6));
            });
        });
        var arr = [...DataSet];
        Data = arr.toString();
        arrData.push(Data);

    });
});
