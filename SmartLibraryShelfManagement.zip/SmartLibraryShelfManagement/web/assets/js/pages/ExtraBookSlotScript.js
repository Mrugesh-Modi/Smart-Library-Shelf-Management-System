document.title="Extra Book Slot Report";
$(document).ready(function ()
{
    var bookid;
    $('#dtBasicExample').DataTable();
    $('.dataTables_length').addClass('bs-select');

    $("#dtBasicExample").on('click', '.btntable', function ()
    {
        var currentRow = $(this).closest("tr");
        bookid = currentRow.find("td:eq(1)").text();
        if (bookid != "")
        {

            $(this).append("<input type='hidden' name='bookid' value='" + bookid + "'/>");
            //$(this).attr("formaction", "http://localhost:8080/SmartLibraryShelfManagement/Testing/check.jsp");

            $(this).attr("formaction", "http://localhost:8080/SmartLibraryShelfManagement/Librarian/Reports/StatisticalReports/book-report-summary.html");
        }

    });



});