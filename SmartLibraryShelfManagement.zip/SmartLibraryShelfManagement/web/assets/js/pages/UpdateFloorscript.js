var jscript_floorwisesubsectiondata;
var jscript_html;
var jscript_newnoofshelvesid;
var jscript_noofshelves;
var jscript_floorid;
var jscript_categoryexceptonfloor;
var jscript_addcounter = 0;
var total;
var exisiting_empty_shelvesdata = [];
var emptyshelves;
document.title="Update Floor";
$(document).ready(function ()
{

    $("#floor").change(function ()
    {
        jscript_floorid = $(this).val();
        $("#item_table").children().remove();
        $("#addnewcategory").children().remove();
        $("#submit").children().remove();
        $("#item").children().remove();
        $("#user_selection_rdbtn").children().remove();

        $.ajax(
                {
                    url: "http://localhost:8080/SmartLibraryShelfManagement/CRUDOperation",
                    type: "POST",
                    data: {floor_info: "floor_info", floorid: jscript_floorid},
                    success: function (data1)
                    {
                        jscript_floorwisesubsectiondata = data1.toString().split(",");
                        jscript_html = "";
                        if (jscript_floorwisesubsectiondata[0] > 0)
                        {
                            jscript_html += "<input type='radio' name='selection' id='add shelf' value='addshelf'/><label for='add shelf'><span></span>Add shelf</label>";
                        }
                        jscript_html += "<input type='radio' name='selection' id='manageshelf' value='manageshelf'/><label for='manageshelf'><span></span>Manage Shelf</label>";

                        $("#user_selection_rdbtn").append(jscript_html);
                    }

                });
    });
    $(document).on('change', 'input[type="radio"][name="selection"]', function ()
    {

        if ($(this).val() == "addshelf")
        {

            $("#item_table").children().remove();
            $("#addnewcategory").children().remove();
            $("#submit").children().remove();
            $("#item").children().remove();
            $("#manageshelfselection").remove();


            jscript_html = '';
            jscript_html += '<tr><th>Present Sub-Section</th><th>Present No of Shelves</th><th>Select No of Shelves</th>';
            for (var i = 1; i < jscript_floorwisesubsectiondata.length - 1; i += 2)
            {
                jscript_newnoofshelvesid = "newnoofshelves" + i;

                jscript_html += "<tr><td><input type='text' class='form-control' name='oldsubsectionname' value='" + jscript_floorwisesubsectiondata[i] + "'readonly/></td>";
                jscript_html += "<td><input type='text' class='form-control' value='" + jscript_floorwisesubsectiondata[i + 1] + "'readonly/></td>";
                jscript_html += "<td><select name='updatenoofshelves' id='" + jscript_newnoofshelvesid + "' class='form-control select_subsection'><option value=0>select</option>";
                for (var j = 1; j <= jscript_floorwisesubsectiondata[0]; j++)
                {
                    jscript_html += "<option value='" + j + "'>" + j + "</option>";
                }
                jscript_html += "</td></tr>";

            }
            $("#item_table").append(jscript_html);
            $("#addnewcategory").append('<button type="button" class="btn btn-success btn-sm add"  id="btn_addnewcategory" >Add New Category </button>');
            $("#submit").append("<input type='hidden' name='CRUD' value='UpdateFloor'/>");
            $("#submit").append("<input type='submit' name='btn_submit' class='btn btn-primary btn-lg btn-block' id='btn_submit' value='submit'>");
        } else
        {
            $("#item_table").children().remove();
            $("#addnewcategory").children().remove();
            $("#submit").children().remove();
            $("#item").children().remove();
            $("#manageshelfselection").remove();

            $.ajax
                    (
                            {
                                url: "http://localhost:8080/SmartLibraryShelfManagement/CRUDOperation",
                                type: "POST",
                                data: {checkexisitngshelves_emptyshelves: "checkexisitngshelves_emptyshelves", floornumber: jscript_floorid},
                                success: function (data1)
                                {

                                    var s = data1.toString();
                                    var p = s.toString();
                                    exisiting_empty_shelvesdata = p.split(",");

                                }
                            }
                    );

            setTimeout(function ()
            {
                jscript_html = "<div id='manageshelfselection'><input type='radio'  name='manageshelfselection' id='deleteshelf' value='deleteshelf'/><label for='deleteshelf'><span></span>Delete Shelf</label>";
                if (exisiting_empty_shelvesdata.length > 4)
                {
                    jscript_html += "<input type='radio' name='manageshelfselection' id='swapshelf' value='swapshelf'><label for='swapshelf'><span></span>Swap Shelf</label>";
                }
                jscript_html += "</div>";
                $("#user_selection_rdbtn").append(jscript_html);

            }, 200);

        }

    });

    $(document).on('change', 'input[type="radio"][name="manageshelfselection"]', function ()
    {
        if ($(this).val() == "deleteshelf")
        {

            $("#item_table").children().remove();
            $("#addnewcategory").children().remove();
            $("#submit").children().remove();
            $("#item").children().remove();


            jscript_html = "";
            jscript_html += "<tr><th>Select Sub Section</th></tr>";
            jscript_html += "<tr><td><select class='form-control' name='deletesubsection' id='deletesubsection'><option value='0'>select sub section</option>";
            for (var i = 0; i < exisiting_empty_shelvesdata.length; i += 4)
            {
                jscript_html += "<option value='" + exisiting_empty_shelvesdata[i] + "'>" + exisiting_empty_shelvesdata[i + 1] + "</option>";
            }
            jscript_html += "</select></td></tr>";

            $("#item_table").append(jscript_html);



        } else
        {
            $("#item_table").children().remove();
            $("#addnewcategory").children().remove();
            $("#submit").children().remove();
            $("#item").children().remove();
            jscript_html = "";
            jscript_html += "<tr><th>Select Sub Section</th></tr>";
            jscript_html += "<tr><td><select class='form-control' name='firstselection' id='firstselection'><option value='0'>select sub section</option>";
            for (var i = 0; i < exisiting_empty_shelvesdata.length; i += 4)
            {
                jscript_html += "<option value='" + exisiting_empty_shelvesdata[i] + "'>" + exisiting_empty_shelvesdata[i + 1] + "</option>";
            }
            jscript_html += "</select></td></tr>";
            $("#item_table").append(jscript_html);

        }

    });

    $(document).on('change', "#deletesubsection", function ()
    {

        $(".secondtr").remove();
        $(".thirdtr").remove();
        $(".fourthtr").remove();
        var value = $(this).val();
        for (var i = 0; i < exisiting_empty_shelvesdata.length; i += 4)
        {
            if (value == exisiting_empty_shelvesdata[i])
            {
                jscript_html = "";
                jscript_html += "<tr class='secondtr'><th>Total No of Shelf</th><th>Empty Number of shelf</th></tr>";
                jscript_html += "<tr class='secondtr'><td><input type='text' class='form-control' name='noofallowed' id='noofallowed' value='" + exisiting_empty_shelvesdata[i + 2] + "' readonly/></td>";
                jscript_html += "<td><input type='text' class='form-control' name='emptyshelves' id='emptyshelves' value='" + exisiting_empty_shelvesdata[i + 3] + "' readonly/></td></tr>";
                emptyshelves = exisiting_empty_shelvesdata[i + 3];
                $("#item_table").append(jscript_html);

            }
        }
        jscript_html = "";
        jscript_html += "<tr class='thirdtr'><th>Select no of shelf you won't to delete</th></tr>";
        jscript_html += "<tr class='thirdtr'><td><select name='noofdeleteshelves' class='form-control' id='noofdeleteshelves'><option value='0'>Select No of Shelf To be Deleted</option>";
        for (var i = 1; i <= emptyshelves; i++)
        {
            jscript_html += "<option value='" + i + "'>" + i + "</option>";
        }
        jscript_html += "</select></td></tr>";
        $("#item_table").append(jscript_html);

    });

    $(document).on('change', "#noofdeleteshelves", function ()
    {


        $("#submit").children().remove();
        $("#submit").append("<input type='hidden' name='CRUD' value='ManageExisitingShelf_DeleteShelf'/>");
        $("#submit").append("<input type='submit' name='btn_submit' class='btn btn-primary btn-lg btn-block' id='btn_manage_delete' value='submit'>");

    });

    $(document).on('click', "#btn_manage_delete", function (event)
    {
        if (confirm("Are you sure you won't to delete the shelf ? this process can't be undo.."))
        {
            $(this).attr("formaction", "http://localhost:8080/SmartLibraryShelfManagement/CRUDOperation");

        } else
        {
            event.preventDefault();
        }


    });




    $(document).on('change', "#firstselection", function ()
    {

        $(".secondtr").remove();
        $(".thirdtr").remove();
        $(".fourthtr").remove();
        var html = "";
        var value = $(this).val();
        html += "<tr class='thirdtr'><th>Select Second Sub Section</th></tr>";
        html += "<tr class='thirdtr'><td><select class='form-control' name='secondselection' id='secondselection'><option value='0'>select sub section</option>";
        for (var i = 0; i < exisiting_empty_shelvesdata.length; i += 4)
        {
            if (value == exisiting_empty_shelvesdata[i])
            {
                jscript_html = "";
                jscript_html += "<tr class='secondtr'><th>Total No Of Shelf</th><th>Empty No of Shelf</th></tr>";
                jscript_html += "<tr class='secondtr'><td><input type='text' class='form-control' name='noofallowed' id='noofallowed' value='" + exisiting_empty_shelvesdata[i + 2] + "' readonly/></td>";
                jscript_html += "<td><input type='text' class='form-control' name='emptyshelves' id='emptyshelves' value='" + exisiting_empty_shelvesdata[i + 3] + "' readonly/></td></tr>";
                emptyshelves = exisiting_empty_shelvesdata[i + 3];
                $("#item_table").append(jscript_html);

            } else
            {
                html += "<option value='" + exisiting_empty_shelvesdata[i] + "'>" + exisiting_empty_shelvesdata[i + 1] + "</option>";
            }
        }
        html += "</select></td></tr>";
        $("#item_table").append(html);

    });
    $(document).on("change", "#secondselection", function ()
    {

        var value = $(this).val();
        $(".fourthtr").remove();
        var html = "";
        for (var i = 0; i < exisiting_empty_shelvesdata.length; i += 4)
        {
            if (value == exisiting_empty_shelvesdata[i])
            {

                html += "<tr class='fourthtr'><th>Total No Of Shelf</th><th>Empty No of Shelf</th><th>select no of shelf that you won't add form uper sub selection</th></tr>";
                html += "<tr class='fourthtr'><td><input type='text' class='form-control' name='noofallowed' id='noofallowed' value='" + exisiting_empty_shelvesdata[i + 2] + "' readonly/></td>";
                html += "<td><input type='text' class='form-control' name='emptyshelves' id='emptyshelves' value='" + exisiting_empty_shelvesdata[i + 3] + "' readonly/></td>";
                html += "<td><select id='thirdselection' class='form-control' name='thirdselection'><option value='0'>select</option>";
                for (var i = 1; i <= $("#emptyshelves").val(); i++)
                {
                    html += "<option value='" + i + "'>" + i + "</option>";
                }
                html += "</select></td></tr>";
                $("#item_table").append(html);

            }
        }


    });

    $(document).on('change', '#thirdselection', function ()
    {
        $("#submit").children().remove();
        $("#emptyshelves").val(emptyshelves - $(this).val());
        $("#submit").append("<input type='hidden' name='CRUD' value='ManageExisitingShelf_SwapShelf'/>");
        $("#submit").append("<input type='submit' name='btn_submit' class='btn btn-primary btn-lg btn-block' id='btn_manage_swap' value='submit'>");


    });

    $(document).on('click', "#btn_manage_swap", function (event)
    {
        if (confirm("Are you sure you won't to change the no of shelf?"))
        {
            $(this).attr("formaction", "http://localhost:8080/SmartLibraryShelfManagement/CRUDOperation");

        } else
        {
            event.preventDefault();
        }


    });


    $(document).on('click', '#btn_addnewcategory', function ()
    {

        $.ajax(
                {
                    url: "http://localhost:8080/SmartLibraryShelfManagement/CRUDOperation",
                    type: "POST",
                    data: {getcategory_except_onfloor: "getcategory_except_onfloor", floorid: jscript_floorid},
                    success: function (data1)
                    {
                        var dummy = data1.toString();
                        jscript_categoryexceptonfloor = dummy.split(",");
                    }

                }
        );
        if (confirm("Are You Sure Yo Won't to add new Category?") == true)
        {
            jscript_noofshelves = "";
            for (var i = 1; i <= jscript_floorwisesubsectiondata[0]; i++)
            {
                jscript_noofshelves += '<option value="' + i + '">' + i + '</option>';
            }
            var jscript_subsection = "";
            for (var i = 0; i < jscript_categoryexceptonfloor.length - 1; i += 2)
            {
                jscript_subsection += '<option value="' + jscript_categoryexceptonfloor[i] + '">' + jscript_categoryexceptonfloor[i + 1] + '</option>';
            }
            var html = '';
            html += '<tr>';
            var selectSubsectionid = "selectSubsection" + jscript_addcounter;
            html += '<td><select name="newsubsectionid" class="form-control select_subsection" id=' + selectSubsectionid + ' required><option value="">Select Sub Section</option>' + jscript_subsection + '</select></td>';
            var selectNoofShelvesid = "selectNoofShelves" + jscript_addcounter;
            html += '<td><select name="newnoofshelves" class="form-control select_noofshelves" id=' + selectNoofShelvesid + '><option value="">Select No Of Shelves</option>' + jscript_noofshelves + '</select></td>';
            html += '<td><button type="button" name="remove" class="btn btn-danger btn-sm remove">-</button></td></tr>';
            $('#item').append(html);
            jscript_addcounter += 1;
        }

    }
    );

    $(document).on('click', '.remove', function ()
    {
        jscript_addcounter -= 1;
        $(this).closest('tr').remove();
    });

    $(document).on("click", "#btn_submit", function (event)
    {
        var count = 0;
        total = 0;
        var datasubsection = new Array();
        for (var i = 0; i < jscript_addcounter; i++)
        {
            var subsectionid = "#selectSubsection" + i;
            var noofshelves = "#selectNoofShelves" + i;
            if ($(subsectionid).val() == "")
            {
                alert("Please Select Sub-section");
                count += 1;
                break;
            } else
            {
                if ($(noofshelves).val() == "")
                {
                    alert("Please Select No of Shelves");
                    count += 1;
                    break;
                } else
                {
                    datasubsection.push($(subsectionid).val());
                    total += parseInt($(noofshelves).val());
                }

            }
        }

        if (datasubsection.length != 0)
        {
            for (var i = 0; i < datasubsection.length; i++)
            {
                for (var j = i + 1; j < datasubsection.length; j++)
                {
                    if (datasubsection[i] == datasubsection[j])
                    {
                        alert("Sub section cant to duplicated please select different ones");
                        count += 1;
                        break;
                    }
                }
            }
        }

        if (count == 0)
        {


            for (var i = 1; i < jscript_floorwisesubsectiondata.length - 1; i += 2)
            {
                total += parseInt($("#newnoofshelves" + i).val());

            }
            if (total > jscript_floorwisesubsectiondata[0])
            {
                alert("Maximum allowed shelves for this floor is " + jscript_floorwisesubsectiondata[0] + " But you selected " + total + " that's reached the limit");
                event.preventDefault();
            } else if (total == 0)
            {
                var cnf = confirm("You don't make any changes..are you sure you won't to leave this page");
                if (cnf == false)
                {
                    event.preventDefault();
                } else
                {
                    event.preventDefault();
                }
            }
            if (total <= jscript_floorwisesubsectiondata[0])
            {
                $("#submit").append("<input type='hidden' name='total' value='" + total + "'>");
                $("#btn_submit").attr("formaction", "http://localhost:8080/SmartLibraryShelfManagement/CRUDOperation");
            }
        } else
        {
            event.preventDefault();
        }


    });
});
