$(document).ready(function ()
{
    var bookid;
    $('#dtBasicExample').DataTable();
    $('.dataTables_length').addClass('bs-select');
    $("#dtBasicExample").on('click', '.btntable', function ()
    {
        var currentRow = $(this).closest("tr");
        bookid = currentRow.find("td:eq(1)").text();
        if (bookid != "")
        {

            $(this).append("<input type='hidden' name='bookid' value='" + bookid + "'/>");
            //$(this).attr("formaction", "http://localhost:8080/SmartLibraryShelfManagement/Testing/check.jsp");

            $(this).attr("formaction", "http://localhost:8080/SmartLibraryShelfManagement/Librarian/Reports/StatisticalReports/book-report-summary.html");
        }

    });

    $("#misplacedbookreport").click(function ()
    {
        window.location.href = "http://localhost:8080/SmartLibraryShelfManagement/Librarian/Reports/GraphicalReports/misplaced-book.html";
    });

    $("#extrabookslots").click(function ()
    {
        window.location.href = "http://localhost:8080/SmartLibraryShelfManagement/Librarian/Reports/StatisticalReports/extra-book-slot-report.html";
    });



    $("#newlyconfiguredbookreport").click(function ()
    {
        window.location.href = "http://localhost:8080/SmartLibraryShelfManagement/Librarian/Reports/StatisticalReports/new-configured-book-reports.html";
    });

    $(".cursor").mouseenter(function ()
    {
        $(this).css("cursor", "pointer");
    });
    $(".word").mouseenter(function ()
    {
        $(this).css("color", "blue").css("font-size", "17px");
    });
    $(".word").mouseleave(function ()
    {
        $(this).css("color", "rgb(152, 166, 173)").css("font-size", "13px");
    });




    $(".fullscreen-container").fadeTo(200, 1);
    $("#modalCart").modal('show');
    $("#btnpasswordsubmit").click(function (event)
    {
        $("#error").text('');
        if ($("#change_pass2").val() != $("#change_pass1").val())
        {
            event.preventDefault();
            $("#error").append("passwrod miss matched");
        } else if ($("#change_pass2").val() == "" && $("#change_pass1").val() == "")
        {
            event.preventDefault();
            $("#error").append("Please fill all fields");
        } else
        {

            $.ajax
                    (
                            {
                                url: "http://localhost:8080/SmartLibraryShelfManagement/LibrarianCRUDOperation",
                                type: 'POST',
                                data: {CRUD: "changepassword", password: $("#change_pass1").val()},
                                success: function (data1)
                                {
                                    if (data1 > 0)
                                    {
                                        alert("Your Password is sucessfully changed");
                                        $("#modalCart").modal('hide');
                                    } else
                                    {
                                        alert(data1);
                                        alert("Oops something wen't wrong please try again later....");
                                    }

                                }

                            }
                    );


        }
    });


});
