window.onload = function () {
    document.addEventListener("contextmenu", function (e)
    {
        e.preventDefault();
        //alert("Right click disabled");
    }, false);
    document.addEventListener("keydown", function (e) {
        //document.onkeydown = function(e) {
        // "I" key
        if (e.ctrlKey && e.shiftKey && e.keyCode === 73)
        {
            disabledEvent(e);
            //alert("These combination are not allowed",disabledEvent(true));
        }
        // "J" key
        if (e.ctrlKey && e.shiftKey && e.keyCode === 74)
        {
            disabledEvent(e);
            //alert("These combination are not allowed",disabledEvent(true));
        }
        // "S" key + macOS
        if (e.keyCode === 83 && (navigator.platform.match("Mac") ? e.metaKey : e.ctrlKey))
        {
            disabledEvent(e);
            //alert("These combination are not allowed",disabledEvent(true));
        }
        // "U" key
        if (e.ctrlKey && e.keyCode === 85) {
            disabledEvent(e);
           //alert("These combination are not allowed",disabledEvent(true));
        }
        // "F12" key
        if (event.keyCode === 123) {
            disabledEvent(e);
            //alert("These combination are not allowed",disabledEvent(true));
        }
    }, false);
    function disabledEvent(e) {
        if (e.stopPropagation) {
            e.stopPropagation();
        } else if (window.event) {
            window.event.cancelBubble = true;
        }
        e.preventDefault();
        return false;
    }
};
