$(document).on("click", "#btn_submit", function (event)
{

    var counter = 0;
    for (var i = 1; i < count; i++)
    {
        var id = "#" + i;
        if ($(id).val() == 1)
        {
            counter++;
        }
    }
    if (counter == 0)
    {
        //$("#btn_submit").attr("formaction", "../../newjsp.jsp");
        $("#btn_submit").attr("formaction", "http://localhost:8080/SmartLibraryShelfManagement/CRUDOperation");
    } else
    {
        alert("Please select all the shelf no of tiers");
        event.preventDefault();
    }

});