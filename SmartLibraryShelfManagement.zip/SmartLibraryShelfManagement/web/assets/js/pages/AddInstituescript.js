document.title = "Add Institute";
$(document).ready(function ()
{
    var counter = 0;
    var counteradd = 0;
    $("#txt_InstitueName").keyup(function ()
    {

        var value = $(this).val();
        if (/^[A-Za-z .&]+$/i.test(value))
        {
            if (value.length > 6)
            {
                $(".error").text('');
                if (counter == 0)
                {
                    var html = '';
                    html += '<div class="table-repsonsive">';
                    html += '<table class="table table-bordered" id="item_table">';
                    html += '<tr><th>Enter Course Name:-</th><th><button type="button" name="add" class="btn btn-success btn-sm add" id="add">+</button></th></tr>';
                    html += '</table>';
                    html += '</div>';
                    $("#firstblock").after(html);
                    counter += 1;
                }

            } else
            {
                $(".table-repsonsive").remove();
                counter = 0;
                $(".error").text("size must be more then 6 character long");
            }

        } else
        {
            $(".table-repsonsive").remove();
            counter = 0;
            $(".error").text("Invalid Institute Name.Institute name must nor contains special character except space,period and ampersand(&)");
        }

    });
    $(document).on("click", ".add", function ()
    {
        counteradd += 1;
        var id = "txt_courseName" + counteradd;
        var errorid = "txt_error" + counteradd;
        var html = '';
        html += '<tr><td><input type="text" class="form-control" name="txt_courseName" id="' + id + '" required autofocus></td><td><button type="button" name="remove" class="btn btn-danger btn-sm remove">-</button></td><td><span id=' + errorid + ' style="color:red"></span></td></tr>';
        $("#item_table").append(html);
        if (counteradd == 1)
        {
            var html = "";
            html += '<div class="form-group" id="btn_add"><input type="hidden" name="CRUD" value="AddInstitue" /><input type="submit" class="btn btn-primary btn-lg btn-block" id="btn_submit" tabindex="2" name="btn_submit"  value="Add"  formaction="http://localhost:8080/SmartLibraryShelfManagement/CRUDOperation" /></div>';
            $("#item_table").after(html);
        }
        $("#" + id).keyup(function ()
        {

            if (!(/^[A-Za-z .&]+$/i.test($(this).val())))
            {
                $("#" + errorid).text("invalid course name.");
                $("#btn_add").hide();
            } else
            {
                $("#" + errorid).text('');
                $("#btn_add").show();
            }

        });
    });
    $(document).on("click", ".remove", function ()
    {
        $(this).closest('tr').remove();
        counteradd -= 1;
        if (counteradd < 1)
        {
            $("#btn_add").remove();
        }
    });
    $("#txt_InstitueName").change(function ()
    {
        var value = $(this).val();
        var checkinstitute = "checkinstitute";
        if (value != "")
        {

            $.ajax(
                    {
                        url: "http://localhost:8080/SmartLibraryShelfManagement/CRUDOperation",
                        type: 'POST',
                        data: {name: value, check_institute: checkinstitute},
                        success: function (data)
                        {
                            if (data != null)
                            {
                                if (data == 1)
                                {
                                    $(".table-repsonsive").remove();
                                    $(".error").text("Institute Name already exists ");
                                    counter = 0;
                                }
                            }
                        }

                    });
        }
    });
});



/*var checkinstitute = "checkinstitute";
 if (value != "")
 {
 
 $.ajax(
 {
 url: "http://localhost:8080/SmartLibraryShelfManagement/CRUDOperation",
 type: 'POST',
 data: {name: value, check_institute: checkinstitute},
 success: function (data)
 {
 if (data != null)
 {
 if (data == 1)
 {
 $(".table-repsonsive").hide();
 $(".error").text("Institute Name already exists ");
 
 
 } else if (data == 2)
 {
 
 $(".error").text("Invalid Institute Name.Size must be more then 6 character long");
 $(".table-repsonsive").hide();
 } else
 {
 $(".error").text('');
 $(".table-repsonsive").append(data);
 
 }
 
 
 }
 }
 
 }
 );
 */
//    }







/*
 });
 
 var counteradd = 0;
 $(document).on("click", ".add", function ()
 {
 counteradd += 1;
 var html = '';
 html += '<tr><td><input type="text" class="form-control" name="txt_courseName" id="txt_courseName" onchange="MyFunc()" required autofocus></td><td><button type="button" name="remove" class="btn btn-danger btn-sm remove">-</button></td></tr>';
 $("#item_table").append(html);
 if (counteradd == 1)
 {
 var html = "";
 html += '<div class="form-group" id="btn_add"><input type="hidden" name="CRUD" value="AddInstitue" /><input type="submit" class="btn btn-primary btn-lg btn-block" id="btn_submit" tabindex="2" name="btn_submit"  value="Add"  formaction="http://localhost:8080/SmartLibraryShelfManagement/CRUDOperation" /></div>';
 $("#item_table").after(html);
 }
 });
 $(document).on("click", ".remove", function ()
 {
 $(this).closest('tr').remove();
 counteradd -= 1;
 if (counteradd < 1)
 {
 $("#btn_add").remove();
 }
 });
 
 
 $("#txt_InstitueName").change(function ()
 {
 var value = $(this).val();
 var checkinstitute = "checkinstitute";
 if (value != "")
 {
 
 $.ajax(
 {
 url: "http://localhost:8080/SmartLibraryShelfManagement/CRUDOperation",
 type: 'POST',
 data: {name: value, check_institute: checkinstitute},
 success: function (data)
 {
 if (data != null)
 {
 if (data == 1)
 {
 $(".table-repsonsive").hide();
 $(".error").show();
 $(".error").text("Institute Name already exists ");
 
 
 } else if (data == 2)
 {
 $(".error").show();
 $(".error").text("Invalid Institute Name");
 $(".table-repsonsive").hide();
 } else
 {
 $(".error").hide();
 $(".table-repsonsive").show();
 
 }
 
 
 }
 }
 
 }
 );
 
 }
 });
 */

