
var floorid;
setTimeout(delayExecution, 2000);
function delayExecution()
{
    $(document).ready(function ()
    {
        for (var i = 0; i < buttoncounter; i++)
        {
            var id = "button" + i;
            $("#" + id).click(function ()
            {
                floorid = $(this).val();
                $("#maincontainer").find("#shelfcontainer").remove();
                $("#shelftitle").remove();
                $.ajax
                        (
                                {
                                    url: 'http://localhost:8080/SmartLibraryShelfManagement/MisplacedBookReportFloorwise',
                                    type: 'POST',
                                    data: {"arrReaderId[]": arrReaderId, "arrData[]": arrData, floorid: floorid},
                                    success: function (data1)
                                    {

                                        if (data1.length > 0)
                                        {
                                            var html = "";
                                            html += '<h2 class="section-title" id="shelftitle">Book Report</h2><form method="POST"><div class="row" id="shelfcontainer"> <div class="col-xl-12 col-sm-8 offset-sm-2 col-md-6 offset-md-3 col-lg-6 offset-lg-10 col-xl-4 offset-xl-0"> <div class="card card-primary"> <div class="card-body"> <div id="shelf"> </div><div id="btn_submit"> <button class="btn btn-primary" id="btn_submit_report">Show Full Report</button></div></div></div></div></div></form>';


                                            $("#maincontainer").append(html);
                                            $("#shelf").append(data1);


                                        } else
                                        {
                                            alert("This floor has no shelf");
                                        }
                                    }
                                }
                        );
            });
        }
        $(document).on("click", "#btn_submit_report", function ()
        {
            $(this).append("<input type='hidden' name='floorid' value='" + floorid + "'/>");
            $(this).attr("formaction", "http://localhost:8080/SmartLibraryShelfManagement/Librarian/Reports/GraphicalReports/misplaced-book-report.html");
        });


    });
}