document.title="Manage Librarian";
$(document).ready(function ()
{
    var username = "";
    var name = "";
    var flag = "";
    var listid = "";

    $("#addLibrarian").click(function ()
    {
        $("#addcontainer").children().remove();
        var html = "";
        html += '<div class="row"> <div class="col-xl-5 col-sm-8 offset-sm-2 col-md-6 offset-md-3 col-lg-6 offset-lg-3 col-xl-4 offset-xl-3"> <form method="POST"> <div class="card card-primary"> <div class="card-header"><h4>Add Librarian</h4></div><div class="card-body"> <div class="form-group"> <label>Enter a Name</label> <input type="text" name="txt_userName" class="form-control" id="txt_userName" required autofocus> <span></span> </div><div class="form-group"> <label>Enter a Email Id</label> <input type="text" class="form-control" id="txt_email" name="txt_email" required autofocus> <span></span> </div><div class="form-group"> <input type="hidden" name="CRUD" value="AddLibrarian"/> <button type="submit" class="btn btn-primary btn-lg btn-block" name="btn_submit" id="btn_submit_addLib"> Add </button> </div></div></div></form> </div></div>';
        $("#addcontainer").append(html);

    });

    $(document).on("click", "#btn_submit_addLib", function (event)
    {
        $("#txt_userName").siblings("span").text('');
        $("#txt_email").siblings("span").text('');

        var txt_userName = $("#txt_userName").val();
        var txt_email = $("#txt_email").val();
        if (txt_userName != "")
        {
            if (!/^[A-Za-z]+$/i.test(txt_userName))
            {
                $("#txt_userName").siblings("span").text("Name must contain only alphabates.").css({"color": "red"});
                event.preventDefault();
            }
        }
        if (txt_email != null)
        {
            if (!/^[a-z0-9](\.?[a-z0-9]){5,}@g(oogle)?mail\.com$/i.test(txt_email))
            {

                $("#txt_email").siblings("span").text("Please Enter a Proper gmail id").css({"color": "red"});
                event.preventDefault();

            }
        }
        $(this).attr("formaction", "http://localhost:8080/SmartLibraryShelfManagement/CRUDOperation");

    });
    $("#librarianlist").on('click', '.btntable', function ()
    {

        var currentRow = $(this).closest("tr");
        listid = currentRow.find("td:eq(0)").text();
        name = currentRow.find("td:eq(1)").text();
        username = currentRow.find("td:eq(2)").text();
        $(".fullscreen-container").fadeTo(200, 1);
        switch ($(this).attr("id"))
        {
            case "changeemail":
                flag = "changeemail";
                break;
            case "changepassword":
                flag = "changepassword";
                break;
            case "chk":
                if ($(this).prop("checked") == true)
                {
                    flag = "accountstatus_enable";
                } else if ($(this).prop("checked") == false)
                {
                    flag = "accountstatus_disable";

                }
                break;
            case "removelibrarian":
                flag = "removelibrarian";
                break;
            default :
                break;
        }


    });


    $("#btnpasswordsubmit").click(function ()
    {
        var pass = $('#auth_password').val();
        $(".fullscreen-container").fadeOut(200);
        $.ajax
                (
                        {
                            url: "http://localhost:8080/SmartLibraryShelfManagement/CRUDOperation",
                            type: "POST",
                            datatype: 'text',
                            data: {CRUD: "checkAdminCredential", username: adminuname, password: pass},
                            success: function (data1)
                            {
                                if (data1 == 1)
                                {
                                    
                                    $("#addcontainer").children().remove();
                                    var html = "";
                                    html += '<div class="row"> <div class="col-xl-5 col-sm-8 offset-sm-2 col-md-6 offset-md-3 col-lg-6 offset-lg-3 col-xl-4 offset-xl-3"> <form method="POST"> <div class="card card-primary"> <div class="card-header"><h4>Change</h4></div><div class="card-body"> <div class="form-group"> <label>Name</label> <input type="text" class="form-control" value=' + name + ' readonly> <span></span> </div><div class="form-group"> <label>Username</label> <input type="text" class="form-control" name="txt_username" value=' + username + ' readonly> <span></span> </div>';
                                    if (flag == "changeemail")
                                    {
                                        html += '<div class="form-group"> <label>Enter a Emailid</label> <input type="text" class="form-control" name="txt_email" id="txt_email" required autofocus> <span></span> </div><div class="form-group"> <input type="hidden" name="CRUD" value="UpdateEmailPassword"/> <button type="submit" class="btn btn-primary btn-lg btn-block" name="btn_submit" id="btn_submit_addLib"> Add </button> </div></div></div></form> </div></div>';
                                        $("#addcontainer").append(html);

                                    } else if (flag == "changepassword")
                                    {
                                        html += '</div><div class="form-group"> <input type="hidden" name="CRUD" value="UpdateEmailPassword"/><input type="hidden" name="txt_password" value="password"/><button type="submit" class="btn btn-primary btn-lg btn-block" name="btn_submit" id="btn_submit_addLib">Send Autogenerate Password to mail</button> </div></div></div></form> </div></div>';
                                        $("#addcontainer").append(html);
                                    } else if (flag == "accountstatus_enable")
                                    {
                                        $.ajax
                                                (
                                                        {
                                                            url: "http://localhost:8080/SmartLibraryShelfManagement/CRUDOperation",
                                                            type: "POST",
                                                            data: {CRUD: "LibrarianEnableDisableRemove", username: username, status: "enable"},
                                                            success: function (data2)
                                                            {
                                                                //alert(data2);
                                                            }

                                                        }
                                                );

                                    } else if (flag == "accountstatus_disable")
                                    {

                                        $.ajax
                                                (
                                                        {
                                                            url: "http://localhost:8080/SmartLibraryShelfManagement/CRUDOperation",
                                                            type: "POST",
                                                            data: {CRUD: "LibrarianEnableDisableRemove", username: username, status: "disable"},
                                                            success: function (data2)
                                                            {
                                                                //alert(data2);
                                                            }

                                                        }
                                                );

                                    } else if (flag == "removelibrarian")
                                    {
                                        $.ajax
                                                (
                                                        {
                                                            url: "http://localhost:8080/SmartLibraryShelfManagement/CRUDOperation",
                                                            type: "POST",
                                                            data: {CRUD: "LibrarianEnableDisableRemove", username: username, del: "user"},
                                                            success: function (data2)
                                                            {
                                                                window.location.reload(true);

                                                            }

                                                        }
                                                );
                                    }


                                } else
                                {
                                    $("#addcontainer").children().remove();
                                    alert("Password is invalid..try again");
                                    if (flag == "accountstatus_enable" || flag == "accountstatus_disable")
                                    {
                                        if ($("tr").eq(listid).find("input").prop("checked") == true)
                                        {
                                            $("tr").eq(listid).find("input").prop("checked", false);
                                        } else
                                        {
                                            $("tr").eq(listid).find("input").prop("checked", true);
                                        }
                                    }


                                }

                            }
                        }

                );
    });
});