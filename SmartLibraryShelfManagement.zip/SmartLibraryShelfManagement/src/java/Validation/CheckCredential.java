/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Validation;

import Database.AuthenticationDatabase;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class CheckCredential extends HttpServlet {

    public static int counter;
    String l_userName;
    String l_password;
    String[] l_credentialData;
    String l_credential;
    PrintWriter out;
    HttpSession s_mysession;

    public void checkCredentialStudent(HttpServletRequest request, HttpServletResponse response) {

        try {
            out = response.getWriter();
            l_credential = AuthenticationDatabase.studentCredential(l_userName, l_password);
            l_credentialData = l_credential.split(" ");
            if (l_credentialData[0].equals("1")) {
                if (l_credentialData[1].equals("1")) {
                    s_mysession = request.getSession(true);
                    s_mysession.setAttribute("s_enrollment", request.getParameter("txt_userName"));
                    response.sendRedirect("http://localhost:8080/SmartLibraryShelfManagement/Members/Memberfunctionality/search-book.html");
                } else {
                    counter = 1;
                    s_mysession = request.getSession(true);
                    s_mysession.setAttribute("s_enrollment", request.getParameter("txt_userName"));
                    response.sendRedirect("http://localhost:8080/SmartLibraryShelfManagement/registration.html");

                }
            } else {
                out.println("<script>alert('Your Username or password is invalid!!!'); window.location.href='http://localhost:8080/SmartLibraryShelfManagement/login.html'</script>");

            }
        } catch (IOException | SQLException | ClassNotFoundException e) {
            out.println(e.getMessage());
        }
    }

    public void checkCredentialFaculty(HttpServletRequest request, HttpServletResponse response) {
        try {
            out = response.getWriter();
            l_credential = AuthenticationDatabase.facultyCredential(l_userName, l_password);
            l_credentialData = l_credential.split(" ");
            if (l_credentialData[0].equals("1")) {
                if (l_credentialData[1].equals("1")) {
                    s_mysession = request.getSession(true);
                    s_mysession.setAttribute("f_enrollment", request.getParameter("txt_userName"));
                     response.sendRedirect("http://localhost:8080/SmartLibraryShelfManagement/Members/Memberfunctionality/search-book.html");

                } else {
                    counter = 1;
                    s_mysession = request.getSession(true);
                    s_mysession.setAttribute("f_enrollment", request.getParameter("txt_userName"));
                    response.sendRedirect("http://localhost:8080/SmartLibraryShelfManagement/registration.html");

                }
            } else {
                out.println("<script>alert('Your Username or password is invalid!!!'); window.location.href='http://localhost:8080/SmartLibraryShelfManagement/login.html'</script>");

            }
        } catch (ClassNotFoundException | SQLException | IOException e) {
            out.println(e.getMessage());
        }
    }

    public void checkCredentialAdminLibrarian(HttpServletRequest request, HttpServletResponse response) {
        try {
            out = response.getWriter();
            ResultSet l_retrivenativeuserinfo = AuthenticationDatabase.nativeUserCredential(l_userName, l_password);
            if (l_retrivenativeuserinfo != null) {
                if (l_retrivenativeuserinfo.next()) {
                    String role = l_retrivenativeuserinfo.getString(1);
                    String username = l_retrivenativeuserinfo.getString(2);
                    String last_login = l_retrivenativeuserinfo.getString(3);
                    if (role.equals("Administrator")) {
                        s_mysession = request.getSession(true);
                        s_mysession.setAttribute("a_username", username);
                        AuthenticationDatabase.loginLogoutStatus(username, true, false);
                        l_retrivenativeuserinfo.close();
                        response.sendRedirect("http://localhost:8080/SmartLibraryShelfManagement/admindashboard.html");
                    } else {
                        int status = l_retrivenativeuserinfo.getInt(4);
                        if (status == 1) {
                            s_mysession = request.getSession(true);
                            s_mysession.setAttribute("l_username", username);
                            if (last_login == null) {
                                s_mysession.setAttribute("l_last_login", "check");
                            }

                            AuthenticationDatabase.loginLogoutStatus(username, true, false);
                            l_retrivenativeuserinfo.close();
                            response.sendRedirect("http://localhost:8080/SmartLibraryShelfManagement/librariandashboard.html");
                        } else {
                            out.println("<script>alert('Your account is temporarily disabled contact administrator to enable your account!!!!'); window.location.href='http://localhost:8080/SmartLibraryShelfManagement/login.html'</script>");
                        }

                    }

                } else {
                    out.println("<script>alert('Your Username or password is invalid!!!'); window.location.href='http://localhost:8080/SmartLibraryShelfManagement/login.html'</script>");
                }
            } else {
                out.println("<script>alert('Your Username or password is invalid!!!'); window.location.href='http://localhost:8080/SmartLibraryShelfManagement/login.html'</script>");

            }

        } catch (SQLException | ClassNotFoundException | IOException e) {
            out.println(e.getMessage());
        }

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        out = response.getWriter();
        if (request.getParameter("btn_submit") != null) {

            counter = 0;
            l_userName = request.getParameter("txt_userName");
            l_password = request.getParameter("txt_password");
            if (!l_userName.equals("") && !l_password.equals("")) {
                try {
                    Long.parseLong(l_userName);
                    if (l_userName.matches("\\d{15}")) {
                        checkCredentialStudent(request, response);
                    } else {
                        out.println("<script>alert('Your Username or password is invalid!!!'); window.location.href='http://localhost:8080/SmartLibraryShelfManagement/login.html'</script>");

                    }
                } catch (NumberFormatException exc_numformat) {
                    if (l_userName.matches("^[a-zA-Z]+[.][a-zA-Z]+@utu.ac.in$")) {
                        checkCredentialFaculty(request, response);
                    } else if (l_userName.matches("^[a-zA-Z]+[_][a-zA-Z0-9]+@utu.ac.in$")) {
                        checkCredentialAdminLibrarian(request, response);
                    } else {
                        out.println("<script>alert('Your Username or password is invalid!!!'); window.location.href='http://localhost:8080/SmartLibraryShelfManagement/login.html'</script>");

                    }

                }
            } else {
                out.print("please Fill all field");
            }

        } else {
            response.sendRedirect("http://localhost:8080/SmartLibraryShelfManagement/login.html");
        }

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);
    }

}
