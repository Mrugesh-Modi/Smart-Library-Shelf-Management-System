/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Validation;

import Database.AuthenticationDatabase;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author mruge
 */
public class checkRegistrationDetails extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        HttpSession s_mysession = request.getSession(false);
        if (s_mysession != null) 
        {

            if (request.getParameter("txt_email") != null && request.getParameter("txt_contactNo") != null && request.getParameter("txt_enrollment") != null) {
                String l_email = request.getParameter("txt_email");
                String l_contect_number = "+91-" + request.getParameter("txt_contactNo");
                String l_enrollment = request.getParameter("txt_enrollment");
                try {
                    if (s_mysession.getAttribute("s_enrollment") != null) {
                        if (l_email.matches("^([\\w]*[\\w\\.]*(?!\\.)@gmail.com)$")) {
                            if (l_contect_number.length() == 14) {
                                if (AuthenticationDatabase.studentRegistration(l_enrollment, l_email, l_contect_number) > 0) {
                                    out.println("<script>alert('Your Registration is sucessfully done.'); window.location.href='http://localhost:8080/SmartLibraryShelfManagement/Members/Memberfunctionality/search-book.html'</script>");
                                }

                            } else {
                                out.println("<script>alert('Please Insert Valid Contect Number.'); window.location.href='http://localhost:8080/SmartLibraryShelfManagement/registration.html'</script>");

                            }
                        } else {
                            out.println("<script>alert('Please Insert Valid Email Address.'); window.location.href='http://localhost:8080/SmartLibraryShelfManagement/registration.html'</script>");

                        }
                    } else {
                        if (l_email.matches("^([\\w]*[\\w\\.]*(?!\\.)@gmail.com)")) {
                            if (l_contect_number.length() == 14) {
                                if (AuthenticationDatabase.facultyRegistration(l_enrollment, l_email, l_contect_number) > 0) {
                                    out.println("<script>alert('Your Registration is sucessfully done.'); window.location.href='http://localhost:8080/SmartLibraryShelfManagement/Members/Memberfunctionality/search-book.html'</script>");

                                }
                            } else {
                                out.println("<script>alert('Please Insert Valid Contect Number.'); window.location.href='http://localhost:8080/SmartLibraryShelfManagement/registration.html'</script>");

                            }
                        } else {
                            out.println("<script>alert('Please Insert Valid Email Address.'); window.location.href='http://localhost:8080/SmartLibraryShelfManagement/registration.html'</script>");

                        }

                    }
                } catch (ClassNotFoundException | SQLException e) {
                    out.println(e.getMessage());
                }

            } else {
                response.sendRedirect("http://localhost:8080/SmartLibraryShelfManagement/login.html");
            }
        } else {
            response.sendRedirect("http://localhost:8080/SmartLibraryShelfManagement/login.html");

        }

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);

    }
}
