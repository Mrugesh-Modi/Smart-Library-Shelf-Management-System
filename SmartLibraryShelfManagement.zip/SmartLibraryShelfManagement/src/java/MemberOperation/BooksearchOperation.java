/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MemberOperation;

import Database.MemberDB;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class BooksearchOperation extends HttpServlet {

    PrintWriter out;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        out = response.getWriter();
        if (request.getParameter("searchbook") != null) {
            if (request.getParameter("searchbook").equals("searchbook")) {
                searchBookOption(request, response);
            }
        }
        if (request.getParameter("findbook") != null) {
            {
                findBookOperation(request, response);
            }
        }
    }

    private void searchBookOption(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        try {
            ResultSet rs = MemberDB.retriveBookTypeName(request.getParameter("value"), request.getParameter("rdo_value"));
            String output = "<ul class='list-unstyled' style='background-color:#eee;cursor: pointer;'>";
            while (rs.next()) {
                output += "<li style='padding: 12px;'>" + rs.getString(1) + "</li>";
            }
            output += "</ul>";
            out.println(output);
        } catch (ClassNotFoundException | SQLException ex) {
            out.println(ex.getMessage());
        }
    }

    private void findBookOperation(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            ResultSet rs = MemberDB.findbook(request.getParameter("value"), request.getParameter("rdo_value"));
            if (rs.next()) {
                out.print("<table class=\"table table-bordered table-md\"><tr><th>FloorNO</th><th>Shelf</th><th>Tier</th></tr>");
                out.print("<tr><td>" + rs.getString(1) + "</td><td>" + rs.getString(2) + "</td><td>" + rs.getString(3) + "</td></tr></table>");
                out.print("<input type=\"submit\" name=\"submit\" class=\"btn btn-primary\" value=\"map\">");
                out.print("@" + rs.getInt(1) + "," + rs.getString(2) + "," + rs.getString(3) + "," + rs.getInt(4));
            } else {
                out.print("<script>alert('book is not avalable');</script>");
            }

        } catch (Exception ex) {
            out.println(ex.getMessage());
        }

    }

}
