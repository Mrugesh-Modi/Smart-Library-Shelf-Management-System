/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LibrarianFunctionality;

import java.sql.SQLException;
import Database.DatabaseConnection;
import java.sql.ResultSet;

/**
 *
 * @author mruge
 */
public class LibrarianReports {

    public static int pendingBookReportCount() throws ClassNotFoundException, SQLException {
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_librarian_dashboard_reports_slsms(?) }");
        DatabaseConnection.CST.setInt(1, 1);
        ResultSet rs = DatabaseConnection.CST.executeQuery();
        if (rs != null) {
            rs.next();
            return rs.getInt(1);
        }
        return 0;
    }

}
