package LibrarianFunctionality;

import Database.LibrarianDB;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LibrarianCRUDOperation extends HttpServlet {

    PrintWriter out;
    public static int l_sectionid;
    HttpSession s_mysession;

    private void retrieveBookInfomation(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            ResultSet l_retrievebookinfo = LibrarianDB.retrieveBookInfo(request.getParameter("value"));
            if (l_retrievebookinfo.next()) {
                l_sectionid = l_retrievebookinfo.getInt(8);
                out.print(l_retrievebookinfo.getString(1) + "," + l_retrievebookinfo.getString(2) + "," + l_retrievebookinfo.getString(3) + "," + l_retrievebookinfo.getString(4) + "," + l_retrievebookinfo.getString(5) + "," + l_retrievebookinfo.getInt(6) + "," + l_retrievebookinfo.getString(7) + "," + l_retrievebookinfo.getInt(8));
            }
        } catch (Exception e) {
            out.println(e.getMessage());
        }
    }

    private void addBookData(HttpServletRequest request, HttpServletResponse response, String userinfo) throws ServletException, IOException {
        try {
            String dimension = (request.getParameter("txt_bookhight") + "*" + request.getParameter("txt_bookwidth") + "*" + request.getParameter("txt_booklength"));

            String BookIsbn = (request.getParameter("txt_eanprefix")) + "-" + (request.getParameter("txt_Registration")) + "-" + (request.getParameter("txt_Registrant")) + "-" + (request.getParameter("txt_Publication")) + "-" + (request.getParameter("txt_CheckDigit"));

            ResultSet l_successful = LibrarianDB.insertBook(request.getParameter("txt_booktitle"), Integer.parseInt(request.getParameter("txt_subsectionid")), request.getParameter("txt_bookauthor"), request.getParameter("txt_bookpublication"), BookIsbn, request.getParameter("txt_booklanguage"), Integer.parseInt(request.getParameter("txt_bookpaperback")), Integer.parseInt(request.getParameter("txt_bookquantity")), dimension, userinfo);
            if (l_successful != null) {
                l_successful.next();
                int id;
                if (request.getParameter("txt_subsection_id") != null) {
                    id = l_sectionid;
                } else {
                    id = Integer.parseInt(request.getParameter("txt_subsectionid"));
                }

                int l_sucess = bookConfigurationOnshelf(Float.parseFloat(request.getParameter("txt_bookwidth")), l_successful.getString(1), id, Integer.parseInt(request.getParameter("txt_bookquantity")), l_successful.getString(2));
                out.println("<script>alert('Book inserted Sucessfully for summary check the bookreport.'); window.location.href='http://localhost:8080/SmartLibraryShelfManagement/Librarian/ManageBookInformation/book-configuration.html'</script>");

            }

        } catch (Exception e) {
            out.print(e.getMessage());
        }
    }

    private int bookConfigurationOnshelf(float width, String book_lib_id, int subsectionid, int bookquantity, String flag) throws ServletException, IOException {

        try {
            int shelf_tier_width = 80;
            int max_allowed_book = (int) (shelf_tier_width / width - 2);
            int l_successful = LibrarianDB.bookConfigurationOnShelf(book_lib_id, max_allowed_book, subsectionid, bookquantity, flag);
            return l_successful;
        } catch (ClassNotFoundException | SQLException e) {
            out.println(e.getMessage());

        }
        return 0;

    }

    private void changePasswordLibrarian(HttpServletRequest request, HttpServletResponse response) {
        String username = s_mysession.getAttribute("l_username").toString();
        String pass = request.getParameter("password");
        try {

            int sucess = LibrarianDB.changePasswordLibrarian(username, pass);
            if (sucess > 0) {
                s_mysession.removeAttribute("l_last_login");
                out.println(sucess);
            }
        } catch (ClassNotFoundException | SQLException e) {
            out.println(e.getMessage());
        }

    }

    private void deleteConfiguredBookReport(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            LibrarianDB.deleteConfiguredBookReport(request.getParameter("bookid"));
        } catch (ClassNotFoundException | SQLException e) {
            out.println(e.getMessage());
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        s_mysession = request.getSession(false);

        if (s_mysession != null && s_mysession.getAttribute("l_username") != null) {

            response.setContentType("text/html");
            out = response.getWriter();

            if (request.getParameter("CRUD") != null) {
                switch (request.getParameter("CRUD")) {
                    case "Add":
                        addBookData(request, response, s_mysession.getAttribute("l_username").toString());
                        break;
                    case "changepassword":
                        changePasswordLibrarian(request, response);
                        break;
                    case "deleteconfiguredbookreports":
                        deleteConfiguredBookReport(request, response);
                    default:
                        break;
                }

            }
            if (request.getParameter("fetchBookInfo") != null) {

                if (request.getParameter("fetchBookInfo").equals("fetchBookInfo")) {
                    retrieveBookInfomation(request, response);
                }
            }
        }
    }

}
