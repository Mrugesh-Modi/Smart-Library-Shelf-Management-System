/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LibrarianFunctionality;

import Database.LibrarianDB;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class MisplacedBookReportFloorwise extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();

        if (request.getParameter("arrReaderId[]") != null && request.getParameter("floorid") != null) {
            String[] arrReaderId = request.getParameterValues("arrReaderId[]");
            String[] arrData = request.getParameterValues("arrData[]");
            int floorid = Integer.parseInt(request.getParameter("floorid"));

            /*out.println(arrReaderId[0]);
            out.println(arrData[0]);
            out.println(floorid);
             */
            int noofshelves = 0;
            HashMap h = new HashMap();
            for (int i = 0; i < arrReaderId.length; i++) {
                h.put(arrReaderId[i], arrData[i]);
            }
            /*out.println(h.get("Reader_1"));*/
            try {
                ArrayList Mastertabledata = new ArrayList();
                ResultSet rs = LibrarianDB.getNoofshelfInFloor(floorid);
                ArrayList<Integer> tier = LibrarianDB.gettierinshelf(floorid);
                ResultSet missplaced = LibrarianDB.checkMissplacedBook(floorid);
                if (rs.next()) 
                {
                    noofshelves = rs.getInt(1);
                    if (tier != null) {
                        for (int c = 0; c < noofshelves; c++) {
                            String shelfid = "S" + (floorid * 100 + c + 1);
                            out.print("<div class='d4'><div class='d5'><center>" + shelfid + "</center></div>");
                            //out.println(tier.get(c));
                            for (int j = 0; j < tier.get(c); j++) 
                            {
                                missplaced.next();
                                String readername = missplaced.getString(1);
                                String bookid = missplaced.getString(2);
                                String shelfno = missplaced.getString(3);
                                String tierid = missplaced.getString(4);
                                int presentbook = missplaced.getInt(5);
                                String allfirebasebook = null;
                                if (h.containsKey(readername)) {
                                    allfirebasebook = h.get(readername).toString();
                                }
                                /* out.println(readername);
                                out.println(bookid);
                                out.println(shelfno);
                                out.println(presentbook);
                                out.println(tierid);
                                out.println(allfirebasebook);*/
                                if (allfirebasebook != null) {
                                    String coma[] = allfirebasebook.split(",");
                                    String shelftierno = shelfno + "_" + (j + 1);
                                    out.print("<b>" + shelftierno + "</b> <div class='d3'>");

                                    for (int i = 0; i < coma.length; i++) {
                                        if (coma[i].startsWith(bookid)) {
                                            out.print("<div class='d1'></div>");
                                        } else {
                                            String missbookid[] = coma[i].split("_");
                                            ArrayList tabledata = new ArrayList();
                                            tabledata.add(shelfid);
                                            tabledata.add(shelftierno);
                                            tabledata.add(missbookid[0]);
                                            tabledata.add((i + 1) + "");
                                            Mastertabledata.add(tabledata);
                                            out.print("<div class='d2'></div>");

                                        }
                                    }
                                    out.print("</div>");
                                }
                            }
                            out.print("</div>");
                        }
                        LibrarianDB.addMisplacedBookData(floorid, Mastertabledata);
                    }

                }

            } catch (Exception e) 
            {
                out.println(e.getMessage());
            }

        } else {
            out.println("nathi avto");
        }

    }
}
