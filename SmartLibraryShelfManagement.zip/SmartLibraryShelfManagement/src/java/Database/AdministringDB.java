package Database;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;

public class AdministringDB {

    //All Floor Related Operation
    public static int addFloor(int max_allowed_shelf, String mainsectiontype, int[] sub_section_id, int[] no_of_shelves) throws ClassNotFoundException, SQLException {
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_insertfloor_slsms(?,?,?) }");
        DatabaseConnection.CST.setInt(1, max_allowed_shelf);
        DatabaseConnection.CST.setString(2, mainsectiontype);
        DatabaseConnection.CST.registerOutParameter(3, Types.INTEGER);
        int l_successful = DatabaseConnection.CST.executeUpdate();
        if (l_successful > 0) {
            int floorid = DatabaseConnection.CST.getInt(3);

            for (int i = 0; i < sub_section_id.length; i++) {
                insertCategoryWiseData(floorid, sub_section_id[i], no_of_shelves[i]);
                for (int j = 0; j < no_of_shelves[i]; j++) {
                    insertIntoShelf(sub_section_id[i], floorid);
                }
            }
        }
        DatabaseConnection.connectionRefused();
        return l_successful;
    }

    public static void insertIntoShelf(int subsectionid, int floorid) throws ClassNotFoundException, SQLException {
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_insertshelf_slsms(?,?) }");
        DatabaseConnection.CST.setInt(1, subsectionid);
        DatabaseConnection.CST.setInt(2, floorid);
        DatabaseConnection.CST.executeUpdate();
    }

    public static int insertCategoryWiseData(int floorid, int subsectionid, int noofshelves) throws ClassNotFoundException, SQLException {
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_insertcategorywisearrngementonfloor_slsms(?,?,?) }");
        DatabaseConnection.CST.setInt(1, floorid);
        DatabaseConnection.CST.setInt(2, subsectionid);
        DatabaseConnection.CST.setInt(3, noofshelves);
        return DatabaseConnection.CST.executeUpdate();
    }

    public static int deleteFloor(int floor_number) throws ClassNotFoundException, SQLException {
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call  pro_deletefloor_slsms(?) }");
        DatabaseConnection.CST.setInt(1, floor_number);
        int l_successful = DatabaseConnection.CST.executeUpdate();
        DatabaseConnection.connectionRefused();
        return l_successful;
    }

    public static int updateFloor(int floor_id, int noofshelves) throws ClassNotFoundException, SQLException {
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_updatefloor_slsms(?,?) }");
        DatabaseConnection.CST.setInt(1, floor_id);
        DatabaseConnection.CST.setInt(2, noofshelves);
        int l_successful = DatabaseConnection.CST.executeUpdate();
        return l_successful;
    }

    public static ResultSet updateCategorywiseData(int floorid, String subsectionname, int noofshelves) throws ClassNotFoundException, SQLException {
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_updatecategorywisearrangementonfloor_slsms(?,?,?) }");
        DatabaseConnection.CST.setInt(1, floorid);
        DatabaseConnection.CST.setString(2, subsectionname);
        DatabaseConnection.CST.setInt(3, noofshelves);
        return DatabaseConnection.CST.executeQuery();

    }

    public static ResultSet retrieveLastFloor() throws ClassNotFoundException, SQLException {
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call  pro_getlastfloor_slsms() }");
        ResultSet l_getlastdata = DatabaseConnection.CST.executeQuery();
        //DatabaseConnection.connectionRefused();
        return l_getlastdata;
    }

    public static ResultSet retrieveAllFloor() throws ClassNotFoundException, SQLException {
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call  pro_getallfloors_slsms() }");
        return DatabaseConnection.CST.executeQuery();
        //DatabaseConnection.connectionRefused();
    }

    public static ResultSet retrieveFloorInformationById(String floorid) throws ClassNotFoundException, SQLException {

        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call  pro_getselectedfloor_slsms(?) }");
        DatabaseConnection.CST.setInt(1, Integer.parseInt(floorid));
        ResultSet l_getlastdata = DatabaseConnection.CST.executeQuery();
        return l_getlastdata;

    }

    public static ResultSet retrieveFloorNoOfShelf(String shelfid) throws ClassNotFoundException, SQLException {

        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_getfloorofshelf_slsms(?) }");
        DatabaseConnection.CST.setString(1, shelfid);
        ResultSet l_getlastdata = DatabaseConnection.CST.executeQuery();
        //DatabaseConnection.connectionRefused();
        return l_getlastdata;

    }

    //All Shelf Related Operation
    public static ResultSet retrieveNoOfTiersOnShelf(String shelfid) throws ClassNotFoundException, SQLException {

        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_getnooftiersofshelf_slsms(?) }");
        DatabaseConnection.CST.setString(1, shelfid);
        ResultSet l_getlastdata = DatabaseConnection.CST.executeQuery();
        //DatabaseConnection.connectionRefused();
        return l_getlastdata;

    }

    public static ResultSet retrieveLatestShelfId() throws ClassNotFoundException, SQLException {

        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_retrievelastshelf_slsms() }");
        ResultSet l_getlastdata = DatabaseConnection.CST.executeQuery();
        //DatabaseConnection.connectionRefused();
        return l_getlastdata;

    }

    public static ArrayList retrieveAllAllowedFloors() throws ClassNotFoundException, SQLException {

        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_retrieveallallowedfloor_slsms() }");
        Boolean results = DatabaseConnection.CST.execute();
        ArrayList<String> l_allfloors = new ArrayList<>();
        while (results) {
            ResultSet rs = DatabaseConnection.CST.getResultSet();
            while (rs.next()) {
                l_allfloors.add(rs.getString(1));
            }
            rs.close();
            results = DatabaseConnection.CST.getMoreResults();
        }
        DatabaseConnection.connectionRefused();
        return l_allfloors;

    }

    public static int addShelf(int[] no_of_tiers, int floor_id, int subsectionid) throws ClassNotFoundException, SQLException {
        int counter = 0;
        int totalnooftier = 0;
        DatabaseConnection.connectionEstablish();
        for (int i = 0; i < no_of_tiers.length; i++) {
            totalnooftier += no_of_tiers[i];
            DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{call pro_shelf_tierconfiguration_slsms(?,?,?)}");
            DatabaseConnection.CST.setInt(1, no_of_tiers[i]);
            DatabaseConnection.CST.setInt(2, floor_id);
            DatabaseConnection.CST.setInt(3, subsectionid);
            if (DatabaseConnection.CST.executeUpdate() > 0) {
                counter++;
            }

        }
        if (counter == no_of_tiers.length) {

            DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{call pro_notassignedbookToassignedbook_slsms(?)}");
            DatabaseConnection.CST.setInt(1, totalnooftier / 2);
            DatabaseConnection.CST.executeUpdate();
            return 1;
        } else {
            return 0;
        }
    }

    public static int updateShelf(String shelfid, int no_of_tiers, int floor_id) throws ClassNotFoundException, SQLException {
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_updateshelf_slsms(?,?) }");
        DatabaseConnection.CST.setString(1, shelfid);
        DatabaseConnection.CST.setInt(2, no_of_tiers);
        int l_successful = DatabaseConnection.CST.executeUpdate();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_updatefloorofshelf_slsms(?,?) }");
        DatabaseConnection.CST.setString(1, shelfid);
        DatabaseConnection.CST.setInt(2, floor_id);
        int l_successful_1 = DatabaseConnection.CST.executeUpdate();
        DatabaseConnection.connectionRefused();
        if (l_successful > 0 && l_successful_1 > 0) {
            return 1;
        } else {
            return 0;
        }
    }

    public static int deleteShelf(String shelfid) throws ClassNotFoundException, SQLException {
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_deleteshelfconfiguration_slsms(?) }");
        DatabaseConnection.CST.setString(1, shelfid);
        int l_successful_1 = DatabaseConnection.CST.executeUpdate();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_deleteshelf_slsms(?) }");
        DatabaseConnection.CST.setString(1, shelfid);
        int l_successful = DatabaseConnection.CST.executeUpdate();
        DatabaseConnection.connectionRefused();
        if (l_successful > 0 && l_successful_1 > 0) {
            return 1;
        } else {
            return 0;
        }
    }

    public static ResultSet retrieveAllMainSectionType() throws ClassNotFoundException, SQLException {
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_retrievemainsectiontype() }");
        ResultSet l_getallmainsectiontype = DatabaseConnection.CST.executeQuery();
        return l_getallmainsectiontype;

    }

    public static ResultSet retriveSubsectionBasedOnMainSection(String mainsectiontype) throws ClassNotFoundException, SQLException {
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_retriveSubsectionBasedOnMainSection(?) }");
        DatabaseConnection.CST.setString(1, mainsectiontype);
        ResultSet l_getsubsectioninfo = DatabaseConnection.CST.executeQuery();
        return l_getsubsectioninfo;

    }

    public static ResultSet retriveSubsectionDetailsFromFloor(int floorid) throws ClassNotFoundException, SQLException {
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_retrivesubsectiondetails_fromfloor_slsms(?) }");
        DatabaseConnection.CST.setInt(1, floorid);
        ResultSet l_getsubsectiondetails = DatabaseConnection.CST.executeQuery();
        return l_getsubsectiondetails;

    }

    public static ResultSet retriveNoofShelvesBasedonSubsection(int subsectionid, int floorid) throws ClassNotFoundException, SQLException {
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_retrive_noofshelves_basedon_subsection(?,?) }");
        DatabaseConnection.CST.setInt(1, subsectionid);
        DatabaseConnection.CST.setInt(2, floorid);
        return DatabaseConnection.CST.executeQuery();

    }

    public static String fillSubsectionSelectBox(String mainsectiontype) {
        String var = "";
        try {
            ResultSet rs = AdministringDB.retriveSubsectionBasedOnMainSection(mainsectiontype);
            while (rs.next()) {

                var += "<option value='" + rs.getString(2) + "'>" + rs.getString(1) + "</option>";
            }
            return var;
        } catch (Exception e) {
            return var;
        }

    }

    //Institue & Course Related Operation
    public static ResultSet checkInstitutename(String Institutename) throws ClassNotFoundException, SQLException {
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_check_institutename_slsms(?) }");
        DatabaseConnection.CST.setString(1, Institutename);
        return DatabaseConnection.CST.executeQuery();

    }

    public static int addInstituteDetails(String Institutename) throws ClassNotFoundException, SQLException {
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_insertInstitute_details_slsms(?) }");
        DatabaseConnection.CST.setString(1, Institutename);
        return DatabaseConnection.CST.executeUpdate();

    }

    public static int addCourseDetails(String Institutename, String CourseName) throws ClassNotFoundException, SQLException {
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_insertCourse_details_slsms(?,?) }");
        DatabaseConnection.CST.setString(1, Institutename);
        DatabaseConnection.CST.setString(2, CourseName);
        return DatabaseConnection.CST.executeUpdate();

    }

    public static ResultSet addRFIDReaderData(long upc) throws ClassNotFoundException, SQLException {
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_addrfidreader_slsms(?) }");
        DatabaseConnection.CST.setLong(1, upc);
        return DatabaseConnection.CST.executeQuery();

    }

    public static ResultSet checkFloorHasBooks(int floorid) throws ClassNotFoundException, SQLException {
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_check_floorhasbooks_slsms(?) }");
        DatabaseConnection.CST.setLong(1, floorid);
        return DatabaseConnection.CST.executeQuery();

    }

    public static ResultSet checkMaxallowedShelvesonFloor(int floorid) throws ClassNotFoundException, SQLException {
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_checkmaxallowedshelvesonfloor_slsms(?) }");
        DatabaseConnection.CST.setLong(1, floorid);
        return DatabaseConnection.CST.executeQuery();

    }

    public static ResultSet checkNoofShelvesOnFloor(int floorid) throws ClassNotFoundException, SQLException {
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_getnoofshelvesinfloor_slsms(?) }");
        DatabaseConnection.CST.setLong(1, floorid);
        return DatabaseConnection.CST.executeQuery();

    }

    public static ResultSet getFloorDataCatergorywise(int floorid) throws ClassNotFoundException, SQLException {
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_getfloor_data_catergorywise_slsms(?) }");
        DatabaseConnection.CST.setLong(1, floorid);
        return DatabaseConnection.CST.executeQuery();
    }

    public static ResultSet getFloorDataExceptCategorywise(int floorid) throws ClassNotFoundException, SQLException {
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_getfloor_data_except_categorywise_slsms(?) }");
        DatabaseConnection.CST.setLong(1, floorid);
        return DatabaseConnection.CST.executeQuery();

    }

    public static ResultSet checkExisitngshelvesEmptyshelves(int floorid) throws ClassNotFoundException, SQLException {

        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_checkexisitngshelves_emptyshelves_slsms(?) }");
        DatabaseConnection.CST.setLong(1, floorid);
        return DatabaseConnection.CST.executeQuery();

    }

    public static int manageExisitingShelfdeleteShelf(int floorid, int subsectionid, int noofdelete, int maxallowedshelves) throws ClassNotFoundException, SQLException {
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_manage_exisiting_shelves_delete_shelves(?,?,?,?) }");
        DatabaseConnection.CST.setInt(1, floorid);
        DatabaseConnection.CST.setInt(2, subsectionid);
        DatabaseConnection.CST.setInt(3, noofdelete);
        DatabaseConnection.CST.setInt(4, maxallowedshelves);
        return DatabaseConnection.CST.executeUpdate();

    }

    public static int manageExisitingShelfswapShelf(int floorid, int subsectionid1, int subsectionid2, int noofshelves) throws ClassNotFoundException, SQLException {
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_manage_exisiting_shelves_swap_shelves(?,?,?,?) }");
        DatabaseConnection.CST.setInt(1, floorid);
        DatabaseConnection.CST.setInt(2, subsectionid1);
        DatabaseConnection.CST.setInt(3, subsectionid2);
        DatabaseConnection.CST.setInt(4, noofshelves);
        return DatabaseConnection.CST.executeUpdate();

    }

    public static int addLibrarian(String lib_name, String email, String pass, String username) throws ClassNotFoundException, SQLException {
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_addLibrarian_slsms(?,?,?,?) }");
        DatabaseConnection.CST.setString(1, lib_name);
        DatabaseConnection.CST.setString(2, email);
        DatabaseConnection.CST.setString(3, pass);
        DatabaseConnection.CST.setString(4, username);
        int sucess = DatabaseConnection.CST.executeUpdate();
        DatabaseConnection.connectionRefused();
        return sucess;

    }

    public static String retriveLastusernameLibrarian() throws ClassNotFoundException, SQLException {
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_generate_librarian_username_slsms() }");
        ResultSet rs = DatabaseConnection.CST.executeQuery();
        if (rs != null) {
            rs.next();
            return rs.getString(1);
        }
        return null;
    }

    public static ResultSet librarianList() throws ClassNotFoundException, SQLException {
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_librarian_list_slsms() }");
        return DatabaseConnection.CST.executeQuery();

    }

    public static int librarianChangeEmailPass(String username, String email, String pass) throws ClassNotFoundException, SQLException {
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_librarian_changeemailpass_slsms(?,?,?) }");
        DatabaseConnection.CST.setString(1, username);
        if (email == null) {
            DatabaseConnection.CST.setNull(2, java.sql.Types.NULL);
        } else {
            DatabaseConnection.CST.setString(2, email);
        }
        if (pass == null) {
            DatabaseConnection.CST.setNull(3, java.sql.Types.NULL);
        } else {
            DatabaseConnection.CST.setString(3, pass);
        }
        int sucess = DatabaseConnection.CST.executeUpdate();
        DatabaseConnection.connectionRefused();
        return sucess;

    }

    public static String retriveLibrarianMail(String username) throws ClassNotFoundException, SQLException {
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_retrive_librarianmail_slsms(?) }");
        DatabaseConnection.CST.setString(1, username);
        ResultSet rs = DatabaseConnection.CST.executeQuery();
        if (rs != null) {
            rs.next();
            return rs.getString(1);
        }
        return null;
    }

    public static int librarianEnabledisableRemove(String username, String state, String del) throws ClassNotFoundException, SQLException {
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_librarian_enabledisable_remove_slsms(?,?,?) }");
        DatabaseConnection.CST.setString(1, username);
        if (state == null) {
            DatabaseConnection.CST.setNull(2, java.sql.Types.NULL);
        } else {
            DatabaseConnection.CST.setString(2, state);
        }
        if (del == null) {
            DatabaseConnection.CST.setNull(3, java.sql.Types.NULL);
        } else {
            DatabaseConnection.CST.setString(3, del);
        }
        int sucess = DatabaseConnection.CST.executeUpdate();
        DatabaseConnection.connectionRefused();
        return sucess;

    }

    public static int adminDasgboardReport(int flag) throws ClassNotFoundException, SQLException {
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_admin_dashboard_report_slsms(?) }");
        DatabaseConnection.CST.setInt(1, flag);
        ResultSet rs=DatabaseConnection.CST.executeQuery();
        if(rs.next())
        {
            return rs.getInt(1);
        }
        return 0;

    }

}
