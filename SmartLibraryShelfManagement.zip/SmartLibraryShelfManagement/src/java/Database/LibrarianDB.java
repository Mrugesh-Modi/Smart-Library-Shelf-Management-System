/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Database;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

/**
 *
 * @author 91973
 */
public class LibrarianDB {

    static ArrayList MasterData;

    public static ResultSet retrieveBookInfo(String title) throws ClassNotFoundException, SQLException {
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_retrievebookinfomation_slsms(?) }");
        DatabaseConnection.CST.setString(1, title);
        ResultSet l_getlastdata = DatabaseConnection.CST.executeQuery();
        return l_getlastdata;
    }

    public static ResultSet insertBook(String booktitle, int booksubsectionid, String bookauthor, String bookpublication, String bookisbn, String booklanguage, int bookpeperback, int bookquantity, String dimension, String userinfo) throws ClassNotFoundException, SQLException {
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call  pro_insert_update_bookdata_slsms(?,?,?,?,?,?,?,?,?,?)}");
        DatabaseConnection.CST.setString(1, booktitle);
        DatabaseConnection.CST.setInt(2, booksubsectionid);
        DatabaseConnection.CST.setString(3, bookauthor);
        DatabaseConnection.CST.setString(4, bookpublication);
        DatabaseConnection.CST.setString(5, bookisbn);
        DatabaseConnection.CST.setString(6, booklanguage);
        DatabaseConnection.CST.setInt(7, bookpeperback);
        DatabaseConnection.CST.setInt(8, bookquantity);
        DatabaseConnection.CST.setString(9, dimension);
        DatabaseConnection.CST.setString(10, userinfo);
        ResultSet l_successful = DatabaseConnection.CST.executeQuery();
        return l_successful;
    }

    public static int bookConfigurationOnShelf(String booklibid, int maxallowedbook, int subsectionid, int bookquantity, String flag) throws ClassNotFoundException, SQLException {
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_bookconfigurationonshelf_slsms(?,?,?,?,?)}");
        DatabaseConnection.CST.setString(1, booklibid);
        DatabaseConnection.CST.setInt(2, maxallowedbook);
        DatabaseConnection.CST.setInt(3, subsectionid);
        DatabaseConnection.CST.setInt(4, bookquantity);
        DatabaseConnection.CST.setString(5, flag);
        return DatabaseConnection.CST.executeUpdate();

    }

    public static ResultSet retrieveAllSubSectionType() throws ClassNotFoundException, SQLException {
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_retrieveallsubsectiontype_slsms()}");
        ResultSet l_retrievesubsection = DatabaseConnection.CST.executeQuery();
        return l_retrievesubsection;

    }

    public static ResultSet getNoofTierInFloor(int floorid) throws ClassNotFoundException, SQLException {
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_getnooftierinfloor_slsms(?)}");
        DatabaseConnection.CST.setInt(1, floorid);
        return DatabaseConnection.CST.executeQuery();
    }

    public static int changePasswordLibrarian(String username, String pass) throws ClassNotFoundException, SQLException {
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_change_password_librarian(?,?)}");
        DatabaseConnection.CST.setString(1, username);
        DatabaseConnection.CST.setString(2, pass);
        int sucess = DatabaseConnection.CST.executeUpdate();
        DatabaseConnection.connectionRefused();
        return sucess;

    }

    public static int librarianDashboardReport(int flag) throws ClassNotFoundException, SQLException {
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_librarian_dashboard_report_slsms(?)}");
        DatabaseConnection.CST.setInt(1, flag);
        ResultSet rs = DatabaseConnection.CST.executeQuery();
        if (rs.next()) {
            return rs.getInt(1);
        } else {
            return 0;
        }

    }

    public static ResultSet getNoofshelfInFloor(int floorid) throws ClassNotFoundException, SQLException {
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_getnoofshelfinfloor_slsms(?)}");
        DatabaseConnection.CST.setInt(1, floorid);
        return DatabaseConnection.CST.executeQuery();
    }

    public static ArrayList gettierinshelf(int floorid) throws ClassNotFoundException, SQLException {
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_gettierinshelf_slsms(?)}");
        DatabaseConnection.CST.setInt(1, floorid);
        Boolean Results = DatabaseConnection.CST.execute();
        ArrayList<Integer> tierinfo = new ArrayList();
        while (Results) {
            ResultSet rs = DatabaseConnection.CST.getResultSet();
            while (rs.next()) {
                tierinfo.add(rs.getInt(1));

            }
            rs.close();
            Results = DatabaseConnection.CST.getMoreResults();
        }
        DatabaseConnection.connectionRefused();
        return tierinfo;

    }

    public static ResultSet checkMissplacedBook(int floorid) throws ClassNotFoundException, SQLException {
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_checkmissplacedbook_slsms(?)}");
        DatabaseConnection.CST.setInt(1, floorid);
        return DatabaseConnection.CST.executeQuery();
    }

    public static ResultSet newlyConfiguredBookReport() throws ClassNotFoundException, SQLException {
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_newlyconfiguredbookreport_slsms()}");
        return DatabaseConnection.CST.executeQuery();
    }

    public static ArrayList bookDetailReports(String bookid, int flag) throws ClassNotFoundException, SQLException {
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_bookdetailReport_slsms(?,?)}");
        DatabaseConnection.CST.setString(1, bookid);
        DatabaseConnection.CST.setInt(2, flag);
        Boolean Results = DatabaseConnection.CST.execute();
        ArrayList master = new ArrayList();
        while (Results) {
            ResultSet rs = DatabaseConnection.CST.getResultSet();
            ResultSetMetaData rms = rs.getMetaData();
            int count = rms.getColumnCount();
            ArrayList temp = new ArrayList();
            while (rs.next()) {
                for (int i = 1; i <= count; i++) {
                    temp.add(rs.getString(i));
                }
            }
            rs.close();
            master.add(temp);
            Results = DatabaseConnection.CST.getMoreResults();
        }
        DatabaseConnection.connectionRefused();
        return master;

    }

    public static int deleteConfiguredBookReport(String bookid) throws ClassNotFoundException, SQLException {
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_deleteconfiguredbookreport_slsms(?)}");
        DatabaseConnection.CST.setString(1, bookid);
        int sucess = DatabaseConnection.CST.executeUpdate();
        DatabaseConnection.connectionRefused();
        return sucess;
    }

    public static ArrayList displayAllBookReports() throws ClassNotFoundException, SQLException {
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_displayallbookreports_slsms()}");
        Boolean Results = DatabaseConnection.CST.execute();
        ArrayList master = new ArrayList();
        while (Results) {
            ResultSet rs = DatabaseConnection.CST.getResultSet();
            ResultSetMetaData rms = rs.getMetaData();
            int count = rms.getColumnCount();
            ArrayList temp = new ArrayList();
            while (rs.next()) {
                for (int i = 1; i <= count; i++) {
                    temp.add(rs.getString(i));
                }
            }
            rs.close();
            master.add(temp);
            Results = DatabaseConnection.CST.getMoreResults();
        }
        DatabaseConnection.connectionRefused();
        return master;

    }

    public static String dashboardGoogleChartReport() throws ClassNotFoundException, SQLException {

        String temp = "";
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_dashboard_googlechartreports_slsms()}");
        ResultSet rs = DatabaseConnection.CST.executeQuery();
        while (rs.next()) {
            temp += rs.getString(1) + ":" + rs.getInt(2) + ",";
        }
        DatabaseConnection.connectionRefused();
        return temp;
    }

    public static ResultSet extraBookslotReports() throws ClassNotFoundException, SQLException {
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_extrabookslot_reports_slsms()}");
        return DatabaseConnection.CST.executeQuery();
    }

    public static void addMisplacedBookData(int floorid, ArrayList data) throws ClassNotFoundException, SQLException {

        LibrarianDB.MasterData = data;

        for (int i = 0; i < LibrarianDB.MasterData.size(); i++) {
            DatabaseConnection.connectionEstablish();
            DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_insertdata_allfloor_misplacedbookdata_slsms(?,?,?,?)}");
            DatabaseConnection.CST.setInt(1, floorid);
            for (int j = 0; j < ((ArrayList) LibrarianDB.MasterData.get(i)).size() - 1; j++) {

                DatabaseConnection.CST.setString(j + 2, ((ArrayList) LibrarianDB.MasterData.get(i)).get(j).toString());
            }
            DatabaseConnection.CST.executeUpdate();
            DatabaseConnection.connectionRefused();
        }

    }

    public static ArrayList misplacedReportFloorWise() throws ClassNotFoundException, SQLException {

        if (LibrarianDB.MasterData != null) {
            for (int i = 0; i < LibrarianDB.MasterData.size(); i++) {
                ArrayList temp = (ArrayList) LibrarianDB.MasterData.get(i);
                DatabaseConnection.connectionEstablish();
                DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_locationofbook_slsms(?)}");
                String data = temp.get(2).toString();
                DatabaseConnection.CST.setString(1, data);
                ResultSet rs = DatabaseConnection.CST.executeQuery();
                if (rs.next()) {
                    temp.add(rs.getInt(1));
                    temp.add(rs.getString(2));
                    temp.add(rs.getString(3));
                }
                DatabaseConnection.connectionRefused();
                LibrarianDB.MasterData.set(i, temp);
            }
            return LibrarianDB.MasterData;
        }
        return null;

    }

}
