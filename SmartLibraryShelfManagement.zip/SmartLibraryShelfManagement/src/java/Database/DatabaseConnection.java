///this is database connection file
package Database;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseConnection {

    public static CallableStatement CST;
    public static Statement ST;
    public static Connection CON;
    static String URL = "jdbc:mysql://localhost:3306/Library?useSSL=false";
    static String USERNAME = "root";
    static String PASSWORD = "root";

    public static void connectionEstablish() throws ClassNotFoundException, SQLException {
        Class.forName("com.mysql.jdbc.Driver");
        CON = DriverManager.getConnection(URL, USERNAME, PASSWORD);

    }

    public static void connectionRefused() throws ClassNotFoundException, SQLException {
        CON.close();
    }

}
