package Database;

import java.sql.ResultSet;
import java.sql.SQLException;

public class AuthenticationDatabase {

    public static int studentRegistration(String enrollment, String email, String contect) throws ClassNotFoundException, SQLException {

        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{call pro_studentregistration_slsms(?,?,?)}");
        DatabaseConnection.CST.setString(1, enrollment);
        DatabaseConnection.CST.setString(2, email);
        DatabaseConnection.CST.setString(3, contect);
        int flag = DatabaseConnection.CST.executeUpdate();
        DatabaseConnection.connectionRefused();
        return flag;
    }

    public static int facultyRegistration(String enrollment, String email, String contect) throws ClassNotFoundException, SQLException {
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{call pro_facultyregistration_slsms(?,?,?)}");
        DatabaseConnection.CST.setString(1, enrollment);
        DatabaseConnection.CST.setString(2, email);
        DatabaseConnection.CST.setString(3, contect);
        int flag = DatabaseConnection.CST.executeUpdate();
        DatabaseConnection.connectionRefused();
        return flag;
    }

    public static String studentCredential(String enrollment, String password) throws ClassNotFoundException, SQLException {
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{call pro_check_studentcredential_slsms(?,?,?,?)}");
        DatabaseConnection.CST.setString(1, enrollment);
        DatabaseConnection.CST.setString(2, password);
        DatabaseConnection.CST.registerOutParameter(3, java.sql.Types.BOOLEAN);
        DatabaseConnection.CST.registerOutParameter(4, java.sql.Types.BOOLEAN);
        DatabaseConnection.CST.execute();
        String Credential = DatabaseConnection.CST.getString(3);
        String registration = DatabaseConnection.CST.getString(4);
        DatabaseConnection.connectionRefused();
        return Credential + " " + registration;

    }

    public static String facultyCredential(String enrollment, String password) throws ClassNotFoundException, SQLException {
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{call pro_check_facultycredential_slsms(?,?,?,?)}");
        DatabaseConnection.CST.setString(1, enrollment);
        DatabaseConnection.CST.setString(2, password);
        DatabaseConnection.CST.registerOutParameter(3, java.sql.Types.BOOLEAN);
        DatabaseConnection.CST.registerOutParameter(4, java.sql.Types.BOOLEAN);
        DatabaseConnection.CST.execute();
        String Credential = DatabaseConnection.CST.getString(3);
        String registration = DatabaseConnection.CST.getString(4);
        DatabaseConnection.connectionRefused();
        return Credential + " " + registration;
    }

    public static ResultSet retriveStudentInfo(String enrollment) throws ClassNotFoundException, SQLException {
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{call pro_retrive_studentinfo_slsms(?)}");
        DatabaseConnection.CST.setString(1, enrollment);
        return DatabaseConnection.CST.executeQuery();

    }

    public static ResultSet retriveFacultyInfo(String enrollment) throws ClassNotFoundException, SQLException {
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{call pro_retrive_facultyinfo_slsms(?)}");
        DatabaseConnection.CST.setString(1, enrollment);
        return DatabaseConnection.CST.executeQuery();

    }

    public static ResultSet nativeUserCredential(String Username, String Password) throws ClassNotFoundException, SQLException {
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{call pro_check_nativeuserinfo_slsms(?,?)}");
        DatabaseConnection.CST.setString(1, Username);
        DatabaseConnection.CST.setString(2, Password);
        return DatabaseConnection.CST.executeQuery();

    }

    public static int loginLogoutStatus(String username, boolean loginflag, boolean logoutflag) throws ClassNotFoundException, SQLException {
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{call pro_login_logout_status(?,?,?)}");
        DatabaseConnection.CST.setString(1, username);
        DatabaseConnection.CST.setBoolean(2, loginflag);
        DatabaseConnection.CST.setBoolean(3, logoutflag);
        int flag = DatabaseConnection.CST.executeUpdate();
        DatabaseConnection.connectionRefused();
        return flag;

    }

}
