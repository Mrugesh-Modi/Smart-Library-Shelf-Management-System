/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Database;

import java.sql.ResultSet;
import java.sql.SQLException;

public class MemberDB {

    public static ResultSet retriveBookTypeName(String searchdata, String searchtype) throws ClassNotFoundException, SQLException {
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_retrive_searchbook_name_slsms(?,?) }");
        DatabaseConnection.CST.setString(1, searchdata);
        DatabaseConnection.CST.setString(2, searchtype);
        ResultSet l_getlastdata = DatabaseConnection.CST.executeQuery();
        return l_getlastdata;
    }

    public static ResultSet findbook(String searchdata, String searchtype) throws ClassNotFoundException, SQLException {
        DatabaseConnection.connectionEstablish();
        DatabaseConnection.CST = DatabaseConnection.CON.prepareCall("{ call pro_searchbook_slsms(?,?)}");
        DatabaseConnection.CST.setString(1, searchdata);
        DatabaseConnection.CST.setString(2, searchtype);
        return DatabaseConnection.CST.executeQuery();

    }

}
