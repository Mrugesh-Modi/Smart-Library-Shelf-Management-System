package AdministratorFunctionality;

import Database.AdministringDB;
import java.io.IOException;
import java.io.PrintWriter;
import java.security.SecureRandom;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Random;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import Mail.Mailer;

public class CRUDOperation extends HttpServlet {

    int successfullflag;
    String operation;
    int floor_id = 0, max_allowed_shelf = 0;
    static int l_successfullflag;
    PrintWriter out;
    ResultSet rs;
    public static int counter = 0;

    public void addFloorInfo(HttpServletRequest request, HttpServletResponse response) {
        try {
            out = response.getWriter();
            max_allowed_shelf = Integer.parseInt(request.getParameter("maxallowedshelf"));
            String main_section_type = request.getParameter("mainsectiontype");
            String[] sub_section = request.getParameterValues("s_subsectionid");
            String[] s_no_of_shelves = request.getParameterValues("s_noofshelves");

            int[] sub_section_id = new int[sub_section.length];
            int[] no_of_shelves = new int[s_no_of_shelves.length];

            for (int i = 0; i < sub_section_id.length; i++) {
                sub_section_id[i] = Integer.parseInt(sub_section[i]);
                no_of_shelves[i] = Integer.parseInt(s_no_of_shelves[i]);
            }
            l_successfullflag = AdministringDB.addFloor(max_allowed_shelf, main_section_type, sub_section_id, no_of_shelves);
            if (l_successfullflag > 0) {
                out.println("<script>alert('Floor Information inserted Sucessfully'); window.location.href='http://localhost:8080/SmartLibraryShelfManagement/Administrator/ManageFloorInformation/floor-add.html'</script>");
            }
        } catch (IOException | ClassNotFoundException | SQLException e) {

            out.println(e.getMessage());

        }
    }

    public void deleteFloorInfo(HttpServletRequest request, HttpServletResponse response) {
        try {
            out = response.getWriter();
            if (request.getParameter("floornumber").equals("0")) {
                out.println("<script>alert('Please Select the Floor Number'); window.location.href='http://localhost:8080/SmartLibraryShelfManagement/Administrator/ManageFloorInformation/floor-delete.html'</script>");

            } else {

                ResultSet rs = AdministringDB.checkFloorHasBooks(Integer.parseInt(request.getParameter("floornumber")));
                rs.next();
                if (rs.getBoolean(1)) {
                    out.print("<script> alert('Sorry You can not delete the Floor beacause It has books in the shelves'); window.location.href='http://localhost:8080/SmartLibraryShelfManagement/Administrator/ManageFloorInformation/floor-delete.html' </script>");

                } else {
                    AdministringDB.deleteFloor(Integer.parseInt(request.getParameter("floornumber")));
                    out.println("<script>alert('Floor Information Deleted Sucessfully'); window.location.href='http://localhost:8080/SmartLibraryShelfManagement/Administrator/ManageFloorInformation/floor-delete.html'</script>");

                }
            }
        } catch (IOException | ClassNotFoundException | SQLException e) {
            out.println(e.getMessage());
        }
    }

    public void addShelfConfiguration(HttpServletRequest request, HttpServletResponse response) {
        try {
            out = response.getWriter();
            String[] l_strnoofshelves = request.getParameterValues("nooftiers");
            int[] l_noofshelves = new int[l_strnoofshelves.length];
            for (int i = 0; i < l_strnoofshelves.length; i++) {
                l_noofshelves[i] = Integer.parseInt(l_strnoofshelves[i]);
            }

            l_successfullflag = AdministringDB.addShelf(l_noofshelves, Integer.parseInt(request.getParameter("floornumber")), Integer.parseInt(request.getParameter("subsection")));
            if (l_successfullflag > 0) {
                out.println("<script>alert('Shelf information added sucessfully'); window.location.href='http://localhost:8080/SmartLibraryShelfManagement/Administrator/ManageShelfInformation/shelf-tier-configuration.html'</script>");
            }
        } catch (IOException | ClassNotFoundException | SQLException e) {
            out.println(e.getMessage());
        }
    }

    public void addInstitue_CourseDetails(HttpServletRequest request, HttpServletResponse response) {
        try {
            out = response.getWriter();
            String[] l_coursename = request.getParameterValues("txt_courseName");
            String l_institutename = request.getParameter("txt_InstitueName");
            l_successfullflag = AdministringDB.addInstituteDetails(l_institutename);
            if (l_successfullflag > 0) {
                for (int i = 0; i < l_coursename.length; i++) {
                    AdministringDB.addCourseDetails(l_institutename, l_coursename[i]);
                }
                out.println("<script>alert('Institute added sucessfully'); window.location.href='http://localhost:8080/SmartLibraryShelfManagement/Administrator/ManageInstitueandCourseDetails/manage-institute-course.html'</script>");

            }

        } catch (ClassNotFoundException | SQLException | IOException e) {
            out.println(e.getMessage());
        }
    }

    public void checkInstitueName(HttpServletRequest request, HttpServletResponse response) {
        try {
            out = response.getWriter();

            String Institiuename = request.getParameter("name");

            if (Institiuename.matches("^+[A-Za-z .&]+$") & Institiuename.length() > 6) {

                ResultSet rs = AdministringDB.checkInstitutename(Institiuename);
                if (rs != null) {
                    if (rs.next()) {
                        int flag = rs.getInt(1);
                        if (flag != 0) {

                            out.println(1);
                        }
                    }
                }

            } else {
                out.println(2);
            }

        } catch (SQLException | ClassNotFoundException | IOException e) {
            out.println(e.getMessage());
        }

    }

    public void addRFIDReaderData(HttpServletRequest request, HttpServletResponse response) {
        try {
            rs = AdministringDB.addRFIDReaderData(Long.parseLong(request.getParameter("txt_upc")));
            if (rs != null) {
                if (rs.next()) {
                    out.println("<script>alert('Reader added sucessfully'); window.location.href='http://localhost:8080/SmartLibraryShelfManagement/Administrator/ManageRFIDReader/add-reader.html'</script>");
                } else {
                    out.println("<script>alert('Oopps something went wrong!!!'); window.location.href='http://localhost:8080/SmartLibraryShelfManagement/Administrator/ManageRFIDReader/add-reader.html'</script>");
                }

            } else {
                out.println("<script>alert('Oopps something went wrong!!!'); window.location.href='http://localhost:8080/SmartLibraryShelfManagement/Administrator/ManageRFIDReader/add-reader.html'</script>");

            }
        } catch (ClassNotFoundException | SQLException e) {
            out.println(e.getMessage());
        }
    }

    public int checkNoofShelvesOnFloor(HttpServletRequest request, HttpServletResponse response) {
        try {
            rs = AdministringDB.checkMaxallowedShelvesonFloor(Integer.parseInt(request.getParameter("floorid")));
            if (rs != null) {
                rs.next();
                if (rs.getInt(1) <= 20) {
                    return (20 - rs.getInt(1));
                } else {
                    return 0;
                }
            }

        } catch (ClassNotFoundException | SQLException e) {
            return 0;
        }
        return 0;
    }

    public String getFloorDataCategorywise(HttpServletRequest request, HttpServletResponse response) {
        try {
            String data = "";
            rs = AdministringDB.getFloorDataCatergorywise(Integer.parseInt(request.getParameter("floorid")));

            if (rs != null) {
                while (rs.next()) {

                    data += rs.getString(1) + "," + rs.getInt(2) + ",";

                }
                rs.close();
                return data;

            }

        } catch (ClassNotFoundException | SQLException e) {
            out.println(e.getMessage());
        }
        return null;
    }

    public String getFloorDataExceptCategorywise(HttpServletRequest request, HttpServletResponse response) {
        try {
            String data = "";
            rs = AdministringDB.getFloorDataExceptCategorywise(Integer.parseInt(request.getParameter("floorid")));
            if (rs != null) {

                while (rs.next()) {

                    data += rs.getInt(1) + "," + rs.getString(2) + ",";

                }
                rs.close();
                return data;
            }
        } catch (ClassNotFoundException | SQLException e) {
            out.println(e.getMessage());
        }
        return null;
    }

    public void updateFloorInfo(HttpServletRequest request, HttpServletResponse response) {
        int floornumber = Integer.parseInt(request.getParameter("floornumber"));
        int total = Integer.parseInt(request.getParameter("total"));
        try {
            int sucessful = AdministringDB.updateFloor(floornumber, total);
            if (sucessful > 0) {

                if (request.getParameter("updatenoofshelves") != null) {
                    try {
                        String[] s_oldsubsectionname = request.getParameterValues("oldsubsectionname");
                        String[] s_updatenoofshelves = request.getParameterValues("updatenoofshelves");
                        int[] updatenoofshelves = new int[s_updatenoofshelves.length];
                        for (int i = 0; i < s_oldsubsectionname.length; i++) {
                            updatenoofshelves[i] = Integer.parseInt(s_updatenoofshelves[i]);
                            ResultSet rs = AdministringDB.updateCategorywiseData(floornumber, s_oldsubsectionname[i], updatenoofshelves[i]);
                            rs.next();
                            int subsectionid = rs.getInt(1);
                            for (int j = 0; j < updatenoofshelves[i]; j++) {
                                AdministringDB.insertIntoShelf(subsectionid, floornumber);
                            }
                        }
                    } catch (ClassNotFoundException | SQLException e) {
                        out.println(e.getMessage());
                    }

                }
                if (request.getParameterValues("newsubsectionid") != null) {

                    try {
                        String[] s_newsubsectionid = request.getParameterValues("newsubsectionid");
                        String[] s_newnoofshelves = request.getParameterValues("newnoofshelves");
                        int[] newsubsectionid = new int[s_newsubsectionid.length];
                        int[] newnoofshelves = new int[s_newnoofshelves.length];
                        for (int i = 0; i < s_newsubsectionid.length; i++) {
                            newsubsectionid[i] = Integer.parseInt(s_newsubsectionid[i]);
                            newnoofshelves[i] = Integer.parseInt(s_newnoofshelves[i]);
                            AdministringDB.insertCategoryWiseData(floornumber, newsubsectionid[i], newnoofshelves[i]);
                            for (int j = 0; j < newnoofshelves[i]; j++) {
                                AdministringDB.insertIntoShelf(newsubsectionid[i], floornumber);
                            }

                        }
                    } catch (ClassNotFoundException | SQLException e) {
                        out.println(e.getMessage());
                    }

                }

            }
            out.println("<script>alert('Updation Perform Sucessfully'); window.location.href='http://localhost:8080/SmartLibraryShelfManagement/Administrator/ManageFloorInformation/Floor-Update.html'</script>");

        } catch (ClassNotFoundException | SQLException e) {
            out.println(e.getMessage());
        }

    }

    public String checkExisitngshelvesEmptyshelves(HttpServletRequest request, HttpServletResponse response) {
        try {
            String data = "";
            rs = AdministringDB.checkExisitngshelvesEmptyshelves(Integer.parseInt(request.getParameter("floornumber")));
            if (rs != null) {
                rs.next();
                data = rs.getString(1);
                return data;
            }
        } catch (ClassNotFoundException | SQLException e) {
            out.println(e.getMessage());
        }
        return null;
    }

    public void manageExisitingShelfdeleteShelf(HttpServletRequest request, HttpServletResponse response) {
        try {

            int sucessfull = AdministringDB.manageExisitingShelfdeleteShelf(Integer.parseInt(request.getParameter("floornumber")), Integer.parseInt(request.getParameter("deletesubsection")), Integer.parseInt(request.getParameter("noofdeleteshelves")), Integer.parseInt(request.getParameter("noofallowed")));
            if (sucessfull > 0) {
                out.print("<script> alert('Shelf Sucessfully deleted'); window.location.href='http://localhost:8080/SmartLibraryShelfManagement/Administrator/ManageFloorInformation/Floor-Update.html' </script>");

            }
        } catch (ClassNotFoundException | SQLException e) {
            out.println(e.getMessage());
        }
    }

    public void manageExisitingShelfswapShelf(HttpServletRequest request, HttpServletResponse response) {
        try {

            AdministringDB.manageExisitingShelfswapShelf(Integer.parseInt(request.getParameter("floornumber")), Integer.parseInt(request.getParameter("firstselection")), Integer.parseInt(request.getParameter("secondselection")), Integer.parseInt(request.getParameter("thirdselection")));

            out.print("<script> alert('Swapping sucessfully done '); window.location.href='http://localhost:8080/SmartLibraryShelfManagement/Administrator/ManageFloorInformation/Floor-Update.html' </script>");

        } catch (ClassNotFoundException | SQLException e) {
            out.println(e.getMessage());
        }
    }

    public String generateRandomPassword() {
        Random random = new SecureRandom();
        String alphabet = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ ><?:{}'-=+!@#$%^&*()abcdefghijklmnopqrstuvwxyz";
        StringBuilder returnValue = new StringBuilder(10);
        for (int i = 0; i < 10; i++) {
            returnValue.append(alphabet.charAt(random.nextInt(alphabet.length())));
        }
        return new String(returnValue);

    }

    public void addLibrarian(HttpServletRequest request, HttpServletResponse response) {
        String name = request.getParameter("txt_userName");
        String email = request.getParameter("txt_email");
        String randompassword = generateRandomPassword();
        try {
            String username = AdministringDB.retriveLastusernameLibrarian();
            if (username != null) {
                Mailer.send(email, "Your username is:- '" + username + "' and Password is:- " + randompassword);
                int sucess = AdministringDB.addLibrarian(name, email, randompassword, username);
                if (sucess > 0) {
                    out.println("<script>alert('Librarian Added Sucessfully'); window.location.href='http://localhost:8080/SmartLibraryShelfManagement/Administrator/ManageUsers/manage-librarian.html'</script>");
                }
            } else {
                out.println("error on username");
            }
        } catch (ClassNotFoundException | SQLException e) {
            out.println(e.getMessage());
        }

    }

    public void checkAdminCredential(HttpServletRequest request, HttpServletResponse response) {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        try {
            rs = Database.AuthenticationDatabase.nativeUserCredential(username, password);
            if (rs.next()) {
                out.println(1);
            } else {
                out.print(0);
            }

        } catch (ClassNotFoundException | SQLException e) {
            out.println(e.getMessage());
        }

    }

    public void librarianChangeEmailPass(HttpServletRequest request, HttpServletResponse response) {
        String password = null;
        String username = request.getParameter("txt_username");
        String email = request.getParameter("txt_email");
        if (request.getParameter("txt_password") != null) {
            password = generateRandomPassword();
        }
        try {

            //out.println(username + "" + password + "" + email);
            int sucess = AdministringDB.librarianChangeEmailPass(username, email, password);
            if (sucess > 0 && email != null) {
                out.println("<script>alert('Email Sucessfully Changed'); window.location.href='http://localhost:8080/SmartLibraryShelfManagement/Administrator/ManageUsers/manage-librarian.html'</script>");

            } else if (password != null) {
                email = AdministringDB.retriveLibrarianMail(username);
                if (email != null) {
                    Mailer.send(email, "Your username is:- '" + username + "' and Password is:- " + password);
                    out.println("<script>alert('Password Sucessfully sent'); window.location.href='http://localhost:8080/SmartLibraryShelfManagement/Administrator/ManageUsers/ManageLibrarian.jsp'</script>");
                }

            }
        } catch (Exception e) {
            out.println(e.getMessage());
        }

    }

    public void librarianEnabledisableRemove(HttpServletRequest request, HttpServletResponse response) {
        String username = request.getParameter("username");
        String status = request.getParameter("status");
        String del = request.getParameter("del");
        if (status != null) {
            if (status.equals("enable")) {
                status = "1";
            } else {
                status = "0";
            }
        }
        try {
            int sucess = AdministringDB.librarianEnabledisableRemove(username, status, del);
            if (sucess > 0) {
                out.println("success");
            } else {
                out.print("Un-Success");
            }
        } catch (ClassNotFoundException | SQLException e) {
            out.println(e.getMessage());
        }

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, NullPointerException {
        out = response.getWriter();

        HttpSession s_mysession = request.getSession(false);
        if (s_mysession != null) {
            if (s_mysession.getAttribute("a_username") != null) {
                response.setContentType("text/html");
                if (request.getParameter("CRUD") != null) {

                    switch (request.getParameter("CRUD")) {

                        //Add Floor
                        case "AddFloor":
                            addFloorInfo(request, response);
                            break;
                        //Update Floor
                        case "UpdateFloor":
                            updateFloorInfo(request, response);
                            break;
                        case "ManageExisitingShelf_DeleteShelf":
                            manageExisitingShelfdeleteShelf(request, response);
                            break;

                        case "ManageExisitingShelf_SwapShelf":
                            manageExisitingShelfswapShelf(request, response);
                            break;

                        //Delete Floor
                        case "DeleteFloor":
                            deleteFloorInfo(request, response);
                            break;
                        //Add Shelf information
                        case "AddShelf":
                            addShelfConfiguration(request, response);
                            break;
                        //Update shelf information
                        case "UpdateShelf":
                            break;
                        case "DeleteShelf":
                            break;
                        //Add Institute Information
                        case "AddInstitue":
                            addInstitue_CourseDetails(request, response);
                            break;
                        //Add Reader Data
                        case "AddRFIDReader":
                            addRFIDReaderData(request, response);
                            break;

                        case "AddLibrarian":
                            addLibrarian(request, response);
                            break;

                        case "checkAdminCredential":
                            checkAdminCredential(request, response);
                            break;

                        case "UpdateEmailPassword":
                            librarianChangeEmailPass(request, response);
                            break;
                        case "LibrarianEnableDisableRemove":
                            librarianEnabledisableRemove(request, response);
                            break;
                        default:
                            break;
                    }
                } else if (request.getParameter("check_institute") != null) {
                    checkInstitueName(request, response);
                } else if (request.getParameter("floor_info") != null) {
                    int noofshelves = checkNoofShelvesOnFloor(request, response);
                    String datacategorywise = getFloorDataCategorywise(request, response);
                    out.println(noofshelves + "," + datacategorywise);
                } else if (request.getParameter("getcategory_except_onfloor") != null) {
                    String dataexceptcategorywise = getFloorDataExceptCategorywise(request, response);
                    out.println(dataexceptcategorywise);
                } else if (request.getParameter("checkexisitngshelves_emptyshelves") != null) {
                    String exisiting_empty_shelvesdata = checkExisitngshelvesEmptyshelves(request, response);
                    out.println(exisiting_empty_shelvesdata);

                }

            } else {
                response.sendRedirect("http://localhost:8080/SmartLibraryShelfManagement/ErrorPages/error403.html");
            }

        } else {
            response.sendRedirect("http://localhost:8080/SmartLibraryShelfManagement/login.html");
        }

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws
            ServletException, IOException, NullPointerException {
        doPost(request, response);
    }

}
